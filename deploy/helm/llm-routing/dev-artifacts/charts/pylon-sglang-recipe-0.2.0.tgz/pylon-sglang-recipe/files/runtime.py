# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Qualify, cache, and supervise one rank of a pinned SGLang recipe."""
import datetime
import fcntl
import hashlib
import http.client
import http.server
import ipaddress
import json
import math
import os
import pathlib
import platform
import shutil
import signal
import socket
import struct
import subprocess
import sys
import threading
import time
import urllib.request
import uuid

GIB = 1024 ** 3


def log(event, **fields):
    print(json.dumps({'time': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'event': event, **fields}), flush=True)


def host_memory():
    for line in pathlib.Path('/proc/meminfo').read_text().splitlines():
        if line.startswith('MemAvailable:'):
            return int(line.split()[1]) * 1024
    raise RuntimeError('Cannot read host MemAvailable')


def command(config, model_path, rank):
    profile = config['profile']
    workload_tokens = config['contextLength'] * config['concurrency']
    token_capacity = profile.get('maxTotalTokens', workload_tokens)
    if type(token_capacity) is not int or token_capacity < workload_tokens:
        raise RuntimeError('maxTotalTokens must cover the configured context and concurrency')
    flags = ['--model-path', str(model_path), '--served-model-name', config['model']['id'],
             '--tp', str(profile['nodes']), '--context-length', str(config['contextLength']),
             '--max-running-requests', str(config['concurrency']), '--max-total-tokens', str(token_capacity),
             '--host', '0.0.0.0', '--port', str(config['ports']['http'])] + profile['flags']
    if profile['nodes'] > 1:
        flags += ['--nnodes', str(profile['nodes']), '--node-rank', str(rank),
                  '--dist-init-addr', config['targets'][0]['address'] + ':' + str(config['ports']['rendezvous'])]
    return ['python3', '-m', 'sglang.launch_server'] + flags


def check_hardware(config, cuda):
    hardware = config['profile']['hardware']
    architecture = platform.machine().lower()
    architecture = {'aarch64': 'arm64', 'x86_64': 'amd64'}.get(architecture, architecture)
    if platform.system().lower() != hardware['os'] or architecture != hardware['architecture']:
        raise RuntimeError('Runtime OS or architecture does not match the hardware profile')
    if type(hardware['gpuCount']) is not int or hardware['gpuCount'] != 1 or cuda.device_count() != 1:
        raise RuntimeError('The hardware profile requires one exclusively assigned GPU per rank')
    gpu = cuda.get_device_name(0)
    allowed = hardware['cudaDeviceNames']
    if not isinstance(allowed, list) or gpu not in allowed:
        raise RuntimeError('Assigned CUDA device does not match the hardware profile: ' + gpu)
    total_gib = cuda.get_device_properties(0).total_memory / GIB
    if hardware['memoryMode'] == 'discrete':
        minimum = hardware.get('minDeviceMemoryGiB')
        if type(minimum) not in (int, float) or not math.isfinite(minimum) or minimum <= 0:
            raise RuntimeError('Discrete hardware profiles require a positive minDeviceMemoryGiB')
        if total_gib < minimum:
            raise RuntimeError('Assigned CUDA device has insufficient memory for the hardware profile')
    elif hardware['memoryMode'] != 'unified':
        raise RuntimeError('Hardware memoryMode must be unified or discrete')
    return {'gpu': gpu, 'cudaTotalMemoryGiB': total_gib}


def qualify(config, rank):
    import torch
    import torch.distributed as dist
    hardware = check_hardware(config, torch.cuda)
    torch.cuda.set_device(0)
    world = config['profile']['nodes']
    if world > 1:
        addr = config['targets'][0]['address']
        dist.init_process_group('nccl', init_method=f"tcp://{addr}:{config['ports']['rendezvous']}",
                                rank=rank, world_size=world, timeout=datetime.timedelta(seconds=180))
    try:
        x = torch.ones(1024 * 1024, device='cuda', dtype=torch.float32) * (rank + 1)
        if world > 1:
            dist.all_reduce(x)
        expected = world * (world + 1) // 2
        if not torch.all(x == expected).item():
            raise RuntimeError('GPU collective returned incorrect data')
        torch.cuda.synchronize()
        log('qualification_pass', rank=rank, nodes=world, nccl=torch.cuda.nccl.version(), **hardware)
    finally:
        if world > 1:
            dist.destroy_process_group()


def nvme_device(device, sys_block=pathlib.Path('/sys/dev/block'), seen=None):
    """Resolve partitions/device-mapper parents and require local PCI NVMe controllers."""
    seen = set() if seen is None else seen
    if device in seen:
        return False
    seen.add(device)
    path = sys_block / device
    if not path.exists():
        return False
    resolved = path.resolve()
    for parent in (resolved, *resolved.parents):
        if parent.name.startswith('nvme') and parent.name[4:].isdigit():
            try:
                return (parent / 'transport').read_text().strip() == 'pcie'
            except OSError:
                return False
    slaves = list((resolved / 'slaves').iterdir()) if (resolved / 'slaves').is_dir() else []
    return bool(slaves) and all(nvme_device((child / 'dev').read_text().strip(), sys_block, seen.copy()) for child in slaves)


def prepare_offload(config, directory=pathlib.Path('/ple')):
    if not config['profile']['offload']:
        return
    device = directory.stat().st_dev
    if not nvme_device(f'{os.major(device)}:{os.minor(device)}'):
        raise RuntimeError('NVMe offload requires /ple to be backed by a verified local NVMe device')
    # This is the chart's disposable emptyDir, never the retained checkpoint cache.
    for path in directory.iterdir():
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        else:
            path.unlink()
    if shutil.disk_usage(directory).free < config['profile']['offloadGiB'] * GIB:
        raise RuntimeError('Insufficient free NVMe space for the profile offload reservation')


def check_fabric(config, rank, net=pathlib.Path('/sys/class/net')):
    targets, profile = config['targets'], config['profile']
    if len(targets) != 2 or targets[0].get('fabric') != targets[1].get('fabric') or not targets[0].get('fabric'):
        raise RuntimeError('TP2 requires two targets on the same verified fabric')
    addresses = [ipaddress.ip_address(target['address']) for target in targets]
    if len(set(addresses)) != 2 or any(address.version != 4 or address.is_unspecified or address.is_loopback or address.is_multicast or address.is_link_local for address in addresses):
        raise RuntimeError('TP2 requires distinct usable IPv4 fabric addresses')
    target = targets[rank]
    interface = target['interface']
    if len(interface.encode()) > 15 or '/' in interface or interface in ('', '.', '..'):
        raise RuntimeError('Invalid fabric interface name')
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        # SIOCGIFADDR returns the IPv4 address assigned to this local interface.
        result = fcntl.ioctl(sock.fileno(), 0x8915, struct.pack('256s', interface.encode()))
    if socket.inet_ntoa(result[20:24]) != target['address']:
        raise RuntimeError('Configured fabric address does not belong to the selected interface')
    if (net / interface / 'operstate').read_text().strip() != 'up':
        raise RuntimeError('The selected fabric interface is not up')
    speed = int((net / interface / 'speed').read_text().strip())
    if speed < profile['minFabricGbps'] * 1000:
        raise RuntimeError('The selected fabric link is below the profile bandwidth minimum')


class StartupBarrier:
    """Pair fresh rank processes before NCCL and serving, without Kubernetes write access."""
    def __init__(self, config, rank):
        self.config, self.rank = config, rank
        identity = {key: config[key] for key in ('release', 'generation', 'model', 'profile', 'targets', 'contextLength', 'concurrency', 'ports')}
        self.state = {'identity': hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest(),
                      'rank': rank, 'attempt': uuid.uuid4().hex, 'peer': None, 'phase': 'preparing'}
        self.peer_attempt = None
        self.last_peer = time.monotonic()
        self.server = None
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def start(self):
        state = self.state
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path not in ('/status', '/started'):
                    self.send_error(404)
                    return
                body = json.dumps(state.copy()).encode()
                self.send_response(200 if self.path == '/status' or state['phase'] == 'serving' else 503)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            def log_message(self, *_):
                pass
        self.server = http.server.ThreadingHTTPServer((self.config['targets'][self.rank]['address'], self.config['ports']['bootstrap']), Handler)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def close(self):
        self.state['phase'] = 'stopped'
        if self.server:
            self.server.shutdown()
            self.server.server_close()

    def peer(self):
        url = f"http://{self.config['targets'][1-self.rank]['address']}:{self.config['ports']['bootstrap']}/status"
        try:
            with self.opener.open(url, timeout=2) as response:
                value = json.load(response)
        except (OSError, ValueError, http.client.IncompleteRead):
            return None
        if not isinstance(value, dict) or value.get('identity') != self.state['identity'] or value.get('rank') != 1-self.rank:
            return None
        attempt = value.get('attempt')
        if not isinstance(attempt, str) or len(attempt) != 32 or any(c not in '0123456789abcdef' for c in attempt):
            return None
        if self.peer_attempt and (attempt != self.peer_attempt or value.get('peer') not in (None, self.state['attempt'])):
            raise RuntimeError('TP2 peer restarted or belongs to a different startup attempt')
        return value

    def wait(self, phases, timeout=600):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            value = self.peer()
            if value and value.get('phase') in phases:
                self.last_peer = time.monotonic()
                return value
            time.sleep(1)
        raise RuntimeError('Timed out waiting for the matching TP2 peer startup phase')

    def pair(self):
        self.state['phase'] = 'ready'
        # Cache preparation may finish hours apart. Do not begin a short NCCL timeout yet.
        value = self.wait(('ready', 'paired'), timeout=14400)
        if value.get('peer') not in (None, self.state['attempt']):
            raise RuntimeError('TP2 peer is already paired with another startup attempt')
        self.peer_attempt = value['attempt']
        self.state.update(peer=self.peer_attempt, phase='paired')
        self.wait(('paired', 'qualified', 'serving'))

    def qualified(self):
        self.state['phase'] = 'qualified'
        self.wait(('qualified', 'serving'))

    def guard(self):
        value = self.peer()
        if value and value.get('phase') in ('qualified', 'serving') and value.get('peer') == self.state['attempt']:
            self.last_peer = time.monotonic()
        elif time.monotonic() - self.last_peer > 30:
            raise RuntimeError('TP2 peer stopped responding; stopping this rank')


def stop(child):
    if child.poll() is not None:
        return
    os.killpg(child.pid, signal.SIGTERM)
    try:
        child.wait(timeout=15)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, signal.SIGKILL)
        child.wait()


def supervise(argv, config, state_dir=pathlib.Path('/tmp'), cgroup=pathlib.Path('/sys/fs/cgroup'), peer_guard=None):
    latch = state_dir / 'recipe-memory-stop.json'
    if latch.exists():
        raise RuntimeError('Memory guard previously stopped this pod. Inspect the cause before replacing the pod.')
    swap = cgroup / 'memory.swap.current'
    if not swap.exists():
        raise RuntimeError('Runtime memory guard requires cgroup v2')
    child = subprocess.Popen(argv, start_new_session=True)
    def terminate(*_):
        stop(child)
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    try:
        while child.poll() is None:
            if peer_guard:
                peer_guard()
            available, swapped = host_memory(), int(swap.read_text())
            if available < 4 * GIB or swapped:
                failure = {'model': config['model']['id'], 'availableBytes': available, 'swapBytes': swapped}
                latch.write_text(json.dumps(failure))
                log('memory_guard_stop', **failure)
                stop(child)
                return 78
            time.sleep(1)
        return child.returncode
    finally:
        stop(child)


def completed_checkpoint(model, cache):
    complete = cache / (model['revision'] + '.complete')
    if not complete.is_file():
        raise RuntimeError('Cache reuse requires a completed download marker for this pinned checkpoint')
    content = complete.read_text().strip()
    # Earlier releases recorded the repository, with the revision in the filename.
    if content == model['repository']:
        return complete
    try:
        identity = json.loads(content)
    except ValueError:
        identity = None
    expected = {'model': model['id'], 'repository': model['repository'], 'revision': model['revision']}
    if not isinstance(identity, dict) or any(identity.get(key) != value for key, value in expected.items()):
        raise RuntimeError('Cached completion marker does not match the model, repository and revision')
    return complete


def cached_blob(path, repository, cache):
    """Resolve Hub files, preserving the ETag when Xet uses a shared blob store."""
    resolved = path.resolve()
    if path.is_file() and resolved.is_relative_to(repository.resolve()):
        return resolved, resolved.name
    if path.is_file() and path.is_symlink():
        # Hub 1.33 links snapshot -> repository/blobs/<ETag> ->
        # hub/blobs/<prefix>/<Xet hash>. The Xet hash is NOT a SHA256 digest.
        alias = pathlib.Path(os.path.abspath(path.parent.resolve() / os.readlink(path)))
        store = repository.resolve().parent / 'blobs'
        if (alias.parent == repository.resolve() / 'blobs' and alias.parent.resolve() == alias.parent
                and alias.is_symlink() and len(alias.name) == 64
                and all(c in '0123456789abcdef' for c in alias.name)):
            target = pathlib.Path(os.path.abspath(alias.parent / os.readlink(alias)))
            if (target.parent.parent == store and target.parent.name == target.name[:2]
                    and len(target.name) == 64 and all(c in '0123456789abcdef' for c in target.name)
                    and store.resolve().is_relative_to(cache.resolve()) and target.resolve() == target
                    and target == resolved and not target.is_symlink()):
                return resolved, alias.name
    raise RuntimeError('Cached snapshot has a missing file or invalid link: ' + path.name)


def reuse_snapshot(model, cache=pathlib.Path('/cache'), require_complete=True, write_marker=True):
    """Validate retained Hugging Face files directly; never import a download client."""
    complete = completed_checkpoint(model, cache) if require_complete else cache / (model['revision'] + '.complete')
    repository = cache / 'huggingface' / 'hub' / ('models--' + model['repository'].replace('/', '--'))
    snapshot = repository / 'snapshots' / model['revision']
    if not repository.resolve().is_relative_to(cache.resolve()) or not snapshot.is_dir() or not snapshot.resolve().is_relative_to(repository.resolve()):
        raise RuntimeError('Pinned model snapshot is missing from the retained cache')
    checked = set()
    for path in snapshot.rglob('*'):
        if path.is_dir():
            continue
        resolved, expected = cached_blob(path, repository, cache)
        # Hub blobs use SHA256 for LFS files and Git blob SHA1 for other files.
        if (resolved, expected) not in checked and len(expected) in (40, 64) and all(c in '0123456789abcdef' for c in expected):
            digest = hashlib.sha256() if len(expected) == 64 else hashlib.sha1(usedforsecurity=False)
            if len(expected) == 40:
                digest.update(('blob ' + str(path.stat().st_size) + '\0').encode())
            with path.open('rb') as stream:
                for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
                    digest.update(chunk)
            if digest.hexdigest() != expected:
                raise RuntimeError('Cached model blob checksum differs: ' + path.name)
            checked.add((resolved, expected))
    def read_json(name):
        try:
            value = json.loads((snapshot / name).read_text())
        except (OSError, ValueError) as error:
            raise RuntimeError('Missing or invalid cached model file: ' + name) from error
        if not isinstance(value, dict) or not value:
            raise RuntimeError('Empty or invalid cached model file: ' + name)
        return value
    read_json('config.json')
    read_json('tokenizer_config.json')
    if (snapshot / 'tokenizer.json').is_file():
        read_json('tokenizer.json')
    elif not (snapshot / 'tokenizer.model').is_file() or (snapshot / 'tokenizer.model').stat().st_size == 0:
        raise RuntimeError('Cached tokenizer files are missing')
    index = snapshot / 'model.safetensors.index.json'
    weight_map = read_json(index.name).get('weight_map') if index.exists() else None
    if index.exists() and (not isinstance(weight_map, dict) or not weight_map or not all(isinstance(name, str) for name in weight_map.values())):
        raise RuntimeError('Cached weight index is empty or invalid')
    weights = set(weight_map.values()) if weight_map else {path.name for path in snapshot.glob('*.safetensors')}
    if not weight_map and weights != {'model.safetensors'}:
        raise RuntimeError('Cached sharded model requires its complete weight index')
    if not weights or any(not isinstance(name, str) or pathlib.PurePath(name).name != name or not name.endswith('.safetensors') for name in weights):
        raise RuntimeError('Cached model weights are missing or invalid')
    for name in weights:
        path = snapshot / name
        try:
            size = path.stat().st_size
            with path.open('rb') as stream:
                length = int.from_bytes(stream.read(8), 'little')
                if not 0 < length <= min(size - 8, 64 * 1024 * 1024):
                    raise ValueError('Invalid safetensors header length')
                header = json.loads(stream.read(length))
            offsets = [value['data_offsets'] for key, value in header.items() if key != '__metadata__']
            if not offsets or any(not isinstance(pair, list) or len(pair) != 2 or
                    any(type(value) is not int for value in pair) or not 0 <= pair[0] <= pair[1] <= size - 8 - length for pair in offsets):
                raise ValueError('Invalid tensor offsets')
            if max(pair[1] for pair in offsets) != size - 8 - length:
                raise ValueError('Truncated or unexpected tensor data')
            if weight_map and any(tensor not in header for tensor, shard in weight_map.items() if shard == name):
                raise ValueError('Weight index refers to missing tensors')
        except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
            raise RuntimeError('Missing or corrupt cached weight shard: ' + name) from error
    if write_marker:
        temporary = complete.with_suffix('.pending')
        temporary.write_text(json.dumps({'model': model['id'], 'repository': model['repository'], 'revision': model['revision']}) + '\n')
        os.replace(temporary, complete)
    return snapshot


def prepare_checkpoint(config, cache):
    model = config['model']
    if config.get('reuseCaches') or (cache / (model['revision'] + '.complete')).exists():
        snapshot = reuse_snapshot(model, cache, write_marker=False)
        log('download_pass', model=model['id'], revision=model['revision'], reused=True)
        return snapshot
    # External downloads can contain a complete, locally verifiable snapshot.
    # Validate locally before importing the download client or requiring free space.
    try:
        snapshot = reuse_snapshot(model, cache, require_complete=False)
    except RuntimeError:
        pass
    else:
        log('download_pass', model=model['id'], revision=model['revision'], reused=True)
        return snapshot
    if shutil.disk_usage(cache).free < config['profile']['minFreeDiskGiB'] * GIB:
        raise RuntimeError('Insufficient cache disk space for the model checkpoint')
    from huggingface_hub import snapshot_download
    snapshot_download(repo_id=model['repository'], revision=model['revision'], cache_dir=str(cache / 'huggingface/hub'))
    snapshot = reuse_snapshot(model, cache, require_complete=False)
    log('download_pass', model=model['id'], revision=model['revision'], reused=False)
    return snapshot


def release_checkpoint_file_cache(config, snapshot):
    enabled = config['profile'].get('releaseCheckpointFileCache', False)
    if type(enabled) is not bool:
        raise RuntimeError('releaseCheckpointFileCache must be a boolean')
    if not enabled:
        return
    # On Grace Blackwell, Linux can cache file pages in GPU NUMA memory.
    # Release only this validated checkpoint's pages before runtime memory sizing.
    # Retain all files and leave other workloads and the global page cache alone.
    count = 0
    for path in snapshot.glob('*.safetensors'):
        with path.open('rb') as stream:
            os.posix_fadvise(stream.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
        count += 1
    log('checkpoint_file_cache_released', files=count)


MMAP_LOADER_SOURCE_SHA256 = '0d16696a77496a5cfbfb4ed2fdfab0654420af57610c46d24ec455b83dfc8e22'
MMAP_LOADER_PATCHED_SHA256 = 'f67cc84d53317a5fcbcea1d837424eae0494339c5846c02d208b3493d2291fe9'
MMAP_LOADER_ANCHOR = '        def device_aware_wrapper(*args, **kwargs):\n'
MMAP_LOADER_REPLACEMENT = MMAP_LOADER_ANCHOR + '''            # Fault mmap pages before entering the CUDA driver's copy lock.
            def materialize(value):
                if isinstance(value, torch.Tensor) and value.device.type == "cpu":
                    return value.clone()
                return value
            args = tuple(materialize(value) for value in args)
            kwargs = {key: materialize(value) for key, value in kwargs.items()}
'''


def patch_mmap_weight_loader(config, path=pathlib.Path('/sgl-workspace/sglang/python/sglang/srt/model_loader/utils.py')):
    """Apply the pinned workaround for upstream sgl-project/sglang#29268."""
    enabled = config['profile'].get('materializeMmapWeights', False)
    if type(enabled) is not bool:
        raise RuntimeError('materializeMmapWeights must be a boolean')
    if not enabled:
        return
    source = path.read_bytes()
    digest = hashlib.sha256(source).hexdigest()
    if digest == MMAP_LOADER_PATCHED_SHA256:
        return
    if digest != MMAP_LOADER_SOURCE_SHA256:
        raise RuntimeError('Mmap loader workaround requires its exact pinned runtime source')
    updated = source.decode().replace(MMAP_LOADER_ANCHOR, MMAP_LOADER_REPLACEMENT).encode()
    if hashlib.sha256(updated).hexdigest() != MMAP_LOADER_PATCHED_SHA256:
        raise RuntimeError('Mmap loader workaround does not match its pinned result')
    # Each pod has its own writable image layer. Neither checkpoint nor image
    # content in the node cache is modified. Spawned workers import this file.
    path.write_bytes(updated)
    log('runtime_patch_applied', patch='deepseek-mmap-materialize', sha256=MMAP_LOADER_PATCHED_SHA256)


def automatic(config, rank, cache=pathlib.Path('/cache')):
    world = config['profile']['nodes']
    if world not in (1, 2) or rank not in range(world):
        raise RuntimeError('Automatic startup requires one or two valid profile ranks')
    with (cache / '.recipe.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('Another model process is using this cache claim') from None
        if host_memory() < config['profile']['memoryGiB'] * GIB:
            raise RuntimeError('Insufficient host MemAvailable for the pinned profile')
        barrier = None
        try:
            if world == 2:
                check_fabric(config, rank)
                import torch
                check_hardware(config, torch.cuda)
                barrier = StartupBarrier(config, rank)
                barrier.start()
                model_path = prepare_checkpoint(config, cache)
                barrier.pair()
            qualify(config, rank)
            import torch
            torch.cuda.empty_cache()
            if barrier:
                barrier.qualified()
            else:
                model_path = prepare_checkpoint(config, cache)
            release_checkpoint_file_cache(config, model_path)
            patch_mmap_weight_loader(config)
            prepare_offload(config)
            if host_memory() < config['profile']['memoryGiB'] * GIB:
                raise RuntimeError('Insufficient host MemAvailable after checkpoint preparation')
            os.environ['HF_HUB_OFFLINE'] = '1'
            os.environ['TRANSFORMERS_OFFLINE'] = '1'
            log('serve_start', model=config['model']['id'], revision=config['model']['revision'], rank=rank)
            if barrier:
                barrier.state['phase'] = 'serving'
                return supervise(command(config, model_path, rank), config, peer_guard=barrier.guard)
            return supervise(command(config, model_path, rank), config)
        finally:
            if barrier:
                barrier.close()


def main():
    config = json.loads(pathlib.Path('/recipe/config.json').read_text())
    rank = int(sys.argv[1])
    if type(config.get('reuseCaches', False)) is not bool:
        raise RuntimeError('reuseCaches must be a boolean')
    log('phase_start', phase='automatic', rank=rank, model=config['model']['id'], revision=config['model']['revision'])
    return automatic(config, rank)


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as e:
        log('phase_failed', reason=str(e))
        sys.exit(1)
