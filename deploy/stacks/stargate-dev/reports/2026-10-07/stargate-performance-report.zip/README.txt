Stargate routing performance - fleet shape report, 2026-10-07

Open report.pdf for the 8-page report, or report.html for its self-contained
browser version. Four figures are available in graphs/ as PNG and SVG.

Scope
The main results are 16 runs on the five-region development fleet with a
half-scale mock engine: a heterogeneous fleet (20 backends, 2-20 GPU workers)
at 350 and 450 requests/s with seeds 1-3, and a homogeneous control (11 GPU
workers per backend) at 450 and 550 requests/s with seed 1. Each fleet run is
matched by a simulator run with the same seed and configuration. A shorter
section covers the seven 2026-10-06 runs with the full-scale engine.

Data
results.json holds run-level values, per-backend tables, per-minute fleet
series, CPU statistics, CFS throttling, each Pylon's input-TPS snapshot, the
engine and policy configuration, and both backend GPU maps. results.csv holds
the run-level metrics in long form. Simulator ranges are observed seeds, not
confidence intervals.

Rebuild
  python3 extract_results.py      (needs the raw campaign directory)
  python3 build_report.py
  python3 render_pdf.py --expected-pages 8

build_report.py needs Matplotlib and NumPy (Python 3.10, Matplotlib 3.10.9).
render_pdf.py needs Chromium and pdfinfo; set REPORT_CHROMIUM for the
executable and REPORT_CHROMIUM_LIBRARIES for an extra library directory.

Production recommendation remains pending real-engine QA.
