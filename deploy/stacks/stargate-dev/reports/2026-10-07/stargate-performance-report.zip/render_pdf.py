"""Print the local report with cached Chromium and verify the resulting PDF."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parent
CHROMIUM = Path(os.environ.get('REPORT_CHROMIUM') or shutil.which('chromium') or shutil.which('google-chrome') or '/usr/bin/chromium')
LIBRARIES = Path(os.environ['REPORT_CHROMIUM_LIBRARIES']) if os.environ.get('REPORT_CHROMIUM_LIBRARIES') else None


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def render(root, expected_pages):
    source = root / 'report.html'
    require(source.is_file(), 'report.html must exist before rendering')
    require(CHROMIUM.is_file(), 'Chromium is missing; set REPORT_CHROMIUM to its executable')
    require(LIBRARIES is None or LIBRARIES.is_dir(), 'Configured Chromium support libraries are missing')
    pdfinfo = shutil.which('pdfinfo')
    require(pdfinfo is not None, 'pdfinfo is required to validate the PDF')
    require(expected_pages is None or expected_pages > 0, '--expected-pages must be positive')
    attempt = Path(tempfile.mkdtemp(prefix='pdf-render-', dir=root))
    output = attempt / 'report.pdf'
    stderr_path = attempt / 'browserstderr.log'
    env = dict(os.environ)
    if LIBRARIES is not None:
        env['LD_LIBRARY_PATH'] = str(LIBRARIES) + (':' + env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
    command = [str(CHROMIUM), '--headless', '--no-sandbox', '--disable-gpu',
               '--disable-dev-shm-usage', '--disable-background-networking', '--no-first-run',
               '--no-default-browser-check', '--no-pdf-header-footer', '--virtual-time-budget=10000',
               '--user-data-dir=' + str(attempt / 'profile'), '--print-to-pdf=' + str(output), source.as_uri()]
    status = {'startedAt': datetime.now(timezone.utc).isoformat(), 'passed': False,
              'html': str(source), 'attemptDirectory': str(attempt), 'command': command,
              'expectedPages': expected_pages, 'pdftotext': shutil.which('pdftotext')}
    try:
        with stderr_path.open('x') as errors, (attempt / 'browserstdout.log').open('x') as stdout:
            process = subprocess.Popen(command, env=env, stdout=stdout, stderr=errors, start_new_session=True)
            try:
                return_code = process.wait(timeout=120)
            finally:
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
        status['browserExitCode'] = return_code
        require(return_code == 0, 'Chromium failed; inspect ' + str(stderr_path))
        require(output.is_file() and output.stat().st_size > 0, 'Chromium did not create a PDF')
        with output.open('rb') as document:
            require(document.read(5) == b'%PDF-', 'Chromium output is not a PDF')
        info = subprocess.run([pdfinfo, str(output)], capture_output=True, text=True, timeout=30)
        (attempt / 'pdfinfo.txt').write_text(info.stdout)
        (attempt / 'pdfinfo.stderr.log').write_text(info.stderr)
        require(info.returncode == 0, 'pdfinfo could not read the rendered PDF')
        match = re.search(r'^Pages:\s+(\d+)\s*$', info.stdout, re.MULTILINE)
        require(match is not None, 'pdfinfo did not report a page count')
        pages = int(match.group(1))
        require(pages > 0, 'Rendered PDF has no pages')
        status['pages'] = pages
        require(expected_pages is None or pages == expected_pages,
                f'Rendered {pages} pages; expected {expected_pages}. PDF retained in {attempt}')
        destination = root / 'report.pdf'
        if destination.exists():
            shutil.copy2(destination, attempt / 'previous-report.pdf')
        temporary = root / ('.report-' + attempt.name + '.pdf')
        shutil.copy2(output, temporary)
        temporary.replace(destination)
        status.update(passed=True, pdf=str(destination), sizeBytes=destination.stat().st_size)
    except BaseException as error:
        status['error'] = str(error)
        raise
    finally:
        status['finishedAt'] = datetime.now(timezone.utc).isoformat()
        (attempt / 'render-status.json').write_text(json.dumps(status, indent=2) + '\n')
        if stderr_path.exists():
            previous_log = root / 'browserstderr.log'
            if previous_log.exists():
                shutil.copy2(previous_log, attempt / 'previous-browserstderr.log')
            shutil.copy2(stderr_path, previous_log)
        previous_status = root / 'pdf-render-status.json'
        if previous_status.exists():
            shutil.copy2(previous_status, attempt / 'previous-render-status.json')
        previous_status.write_text(json.dumps(status, indent=2) + '\n')
    print(f"Rendered {pages} pages: {destination}")
    print('Browser log: ' + str(root / 'browserstderr.log'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--expected-pages', type=int)
    arguments = parser.parse_args()
    render(arguments.root.resolve(), arguments.expected_pages)
