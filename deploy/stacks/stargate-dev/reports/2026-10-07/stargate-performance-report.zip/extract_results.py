"""Extract the 2026-10-06/07 simulator and dev-fleet results into results.json and results.csv.

Inputs (not shipped in the bundle; paths are relative to the campaign directory):
  sim2/*-out.json                      simulator run summaries
  bench.json                           workload, client and policy configuration
  backend_gpus-hetero.json, backend_gpus-homo.json
  fleet/<run>/{summary.json,*.jsonl}   fleet driver summaries and per-request records
  fleet/<run>.cpu.jsonl                kubelet CPU samples every 30 s
  fleet/<run>.throttle.json            CFS throttling and Pylon input-TPS snapshots (c2 runs)
  fleet/campaign.log                   run start times
"""
from __future__ import annotations

import csv
import json
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

CAMPAIGN = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(CAMPAIGN / "report"))
from extract_results import cpu_stats, per_minute, run_starts  # noqa: E402

POLICIES = {"waw": "wait-and-widen", "pulsar-waw": "pulsar-wait-and-widen",
            "power-of-n": "power-of-n", "round-robin": "round-robin"}
FULL_SCALE_RUNS = ["c1-waw-250", "c1-pulsar-waw-250", "c1-waw-550", "c1-pulsar-waw-550",
                   "c1-waw-900", "c1-pulsar-waw-900", "c1-power-of-n-250"]


def sim_rows(name, scale, fleet):
    rows = []
    for run in json.loads((CAMPAIGN / "sim2" / name).read_text()):
        rows.append({
            "scale": scale, "fleet": fleet, "policy": run["policy"], "rate_rps": int(run["rate_rps"]),
            "seed": run["seed"], "offered_rps": run["offered"] / 240.0,
            "goodput_rps": run["goodput_rps"], "slo_attainment": run["slo_attainment"],
            "reuse": run["reused_input_token_fraction"],
            "ttft_p50_ms": run["ttft_ms"]["p50"], "ttft_p99_ms": run["ttft_ms"]["p99"],
            "failed": run["failed_no_route"] + run["failed_retries_exhausted"] + run["failed_timeout"],
            "backends": [{"id": b["id"], "gpu_workers": b["gpu_workers"], "succeeded": b["succeeded"],
                          "ttft_p50_ms": b["ttft_ms"]["p50"], "reuse": b["reused_input_token_fraction"]}
                         for b in run["backends"]],
        })
    return rows


def throttle(label):
    path = CAMPAIGN / "fleet" / f"{label}.throttle.json"
    if not path.exists():
        return None
    data = json.loads(path.read_text())
    start, end = data["measure_start"], data["measure_end"]
    fractions = []
    for key, counters in end.items():
        if key in start:
            periods = counters.get("periods", 0) - start[key].get("periods", 0)
            if periods > 0:
                fractions.append((counters.get("throttled_periods", 0)
                                  - start[key].get("throttled_periods", 0)) / periods)
    weights = {}
    for key, values in data["pylon_tps_end"].items():
        context, pod = key.split("/")
        index = pod.split("-backend-")[1].split("-")[0]
        weights[f"{context}-backend-{index}"] = values
    return {"containers": len(fractions), "max_throttled_fraction": max(fractions, default=0.0),
            "pylon_tps_end": weights}


def fleet_row(label, gpus, starts, warmup, measure):
    parts = label.split("-")
    seed = int(parts[-1][1:]) if parts[-1].startswith("s") else 1
    rate = int(parts[-2] if parts[-1].startswith("s") else parts[-1])
    name = next(key for key in sorted(POLICIES, key=len, reverse=True) if f"-{key}-" in f"-{label}-")
    summary = json.loads((CAMPAIGN / "fleet" / label / "summary.json").read_text())[0]
    records = []
    for path in sorted((CAMPAIGN / "fleet" / label).glob("*.jsonl")):
        records.extend(json.loads(line) for line in path.read_text().splitlines() if line.strip())
    window = (warmup * 1e6, (warmup + measure) * 1e6)
    return {
        "label": label, "policy": POLICIES[name], "rate_rps": rate, "seed": seed,
        "offered_rps": summary["offered"] / measure, "goodput_rps": summary["goodput_rps"],
        "slo_attainment": summary["slo_attainment"], "reuse": summary["reused_input_token_fraction"],
        "ttft_p50_ms": summary["ttft_ms"]["p50"], "ttft_p99_ms": summary["ttft_ms"]["p99"],
        "failures": summary["failures"], "failed": sum(summary["failures"].values()),
        "failures_by_backend": dict(Counter(r["cluster_id"] or "unrouted" for r in records
                                            if r["error"] and window[0] <= r["arrival_us"] < window[1])),
        "backends": [{"id": b["cluster_id"], "gpu_workers": gpus.get(b["cluster_id"]),
                      "succeeded": b["succeeded"], "ttft_p50_ms": b["ttft_ms"]["p50"],
                      "ttft_p99_ms": b["ttft_ms"]["p99"], "reuse": b["reused_input_token_fraction"]}
                     for b in summary["backends"]],
        "cpu": cpu_stats(label, starts[label], warmup, measure),
        "throttle": throttle(label),
        "minutes": per_minute(records),
    }


def main():
    bench = json.loads((CAMPAIGN / "bench.json").read_text())
    warmup, measure = bench["workload"]["warmup_s"], bench["workload"]["measure_s"]
    starts = run_starts()
    done = json.loads((CAMPAIGN / "fleet" / "done.json").read_text())
    hetero = json.loads((CAMPAIGN / "backend_gpus-hetero.json").read_text())
    homo = json.loads((CAMPAIGN / "backend_gpus-homo.json").read_text())
    half_engine = json.loads((CAMPAIGN / "sim2" / "hetero-half.json").read_text())["engine"]
    full_engine = json.loads((CAMPAIGN / "sim2" / "hetero.json").read_text())["engine"]
    results = {
        "dates": "2026-10-06 to 2026-10-07",
        "config": {key: bench[key] for key in ("topology", "pylon", "stargate", "client", "workload")},
        "engines": {"full": full_engine, "half": half_engine},
        "policies": {p["name"]: p["load_balancer"] for p in bench["policies"]},
        "backend_gpus": {"hetero": hetero, "homo": homo},
        "simulator": (sim_rows("hetero-half-out.json", "half", "hetero")
                      + sim_rows("hetero-half-s3-out.json", "half", "hetero")
                      + sim_rows("homo-half-out.json", "half", "homo")
                      + sim_rows("hetero-out.json", "full", "hetero")
                      + sim_rows("homo-out.json", "full", "homo")),
        "fleet": [dict(fleet_row(label, hetero if "homo" not in label else homo, starts, warmup, measure),
                       scale="half" if label.startswith("c2-") else "full",
                       fleet="homo" if "homo" in label else "hetero")
                  for label in [l for l in done if l.startswith("c2-")] + FULL_SCALE_RUNS],
        "excluded_fleet_runs": {"c1-waw-900-nofile1024": "driver open-file soft limit 1,024 caused connect failures"},
    }
    (OUT / "results.json").write_text(json.dumps(results, indent=1))
    keys = ["offered_rps", "goodput_rps", "slo_attainment", "reuse", "ttft_p50_ms", "ttft_p99_ms"]
    with (OUT / "results.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["source", "scale", "fleet", "policy", "rate_rps", "seed", "metric", "value"])
        for source in ("simulator", "fleet"):
            for row in results[source]:
                for key in keys:
                    writer.writerow([source, row["scale"], row["fleet"], row["policy"], row["rate_rps"],
                                     row["seed"], key, row[key]])
    print(f"simulator rows {len(results['simulator'])}, fleet rows {len(results['fleet'])}")


if __name__ == "__main__":
    main()
