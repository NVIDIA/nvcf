"""Build the 2026-10-07 Stargate routing report (HTML and figures) from results.json."""
from __future__ import annotations

import base64
import hashlib
import html
import json
import statistics
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
CHARTS = ROOT / "graphs"
CHARTS.mkdir(exist_ok=True)
INK, MUTED, GREY = "#192e43", "#536575", "#8a99a8"
GREEN, ORANGE, BLUE = "#087d68", "#bc620c", "#2864ba"
NAMES = {"wait-and-widen": "WaW", "pulsar-wait-and-widen": "Pulsar-WaW", "power-of-n": "PowerOf2"}
COLORS = {"WaW": GREEN, "Pulsar-WaW": ORANGE, "PowerOf2": BLUE}
WAW, PULSAR = "wait-and-widen", "pulsar-wait-and-widen"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
    "axes.labelcolor": INK, "text.color": INK, "xtick.color": MUTED,
    "ytick.color": MUTED, "axes.titleweight": "bold", "axes.titlesize": 10,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#b8c4ce", "grid.color": "#e4e9ef",
    "grid.linewidth": .65, "svg.fonttype": "none", "savefig.facecolor": "white"})

DATA = json.loads((ROOT / "results.json").read_text())
SIM, FLEET = DATA["simulator"], DATA["fleet"]
ENGINES = DATA["engines"]


def clean_axis(ax, title, ylabel=None):
    ax.set_title(title, loc="left", pad=11)
    if ylabel:
        ax.set_ylabel(ylabel)
    ax.set_axisbelow(True)
    ax.grid(axis="y")
    ax.tick_params(labelsize=8)


def save_figure(fig, name):
    for extension in ("svg", "png"):
        fig.savefig(CHARTS / f"{name}.{extension}", dpi=190, bbox_inches="tight", pad_inches=.13)
    plt.close(fig)


def figure(name, caption, height=None):
    encoded = base64.b64encode((CHARTS / (name + ".svg")).read_bytes()).decode()
    style = f' style="height:{height}mm"' if height else ""
    return (f'<figure><img alt="{html.escape(caption)}" src="data:image/svg+xml;base64,{encoded}"{style}>'
            f'<figcaption>{caption}</figcaption></figure>')


def table(headers, rows, cls=""):
    return ('<table class="' + cls + '"><thead><tr>' + ''.join('<th>' + html.escape(str(x)) + '</th>' for x in headers)
            + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join('<td>' + html.escape(str(x)) + '</td>' for x in row)
            + '</tr>' for row in rows) + '</tbody></table>')


def para(text, cls=""):
    return f'<p class="{cls}">{text}</p>'


def bullets(items):
    return '<ul>' + ''.join('<li>' + x + '</li>' for x in items) + '</ul>'


PAGES = []


def page(kicker, title, body):
    PAGES.append(f'<section class="page"><header><span>STARGATE / ROUTING PERFORMANCE</span><span>07 OCT 2026</span></header>'
                 f'<div class="kicker">{kicker}</div><h1>{title}</h1><main>{body}</main>'
                 f'<footer><span>Five-region development fleet | Simulator and dev-cluster runs</span>'
                 f'<span>{len(PAGES)+1:02d}</span></footer></section>')


STYLE = """
* {box-sizing:border-box} body {margin:0;background:#e8edf2;color:#192e43;font:12px/1.48 Arial,Helvetica,sans-serif}
.page {width:210mm;height:297mm;padding:12mm;margin:18px auto;background:white;position:relative;box-shadow:0 3px 15px #22334422}
header {display:flex;justify-content:space-between;font-size:8px;letter-spacing:1.1px;border-bottom:1px solid #ccd7e1;padding-bottom:8px;color:#536575}
.kicker {font-size:9px;letter-spacing:1.2px;text-transform:uppercase;color:#087d68;margin-top:15px;font-weight:700}
h1 {font-size:25px;line-height:1.13;margin:5px 0 13px;letter-spacing:-.5px} h2 {font-size:15px;margin:16px 0 5px} h3 {font-size:12px;margin:13px 0 4px}
p {margin:7px 0 10px} .lead {font-size:14px;line-height:1.45} .small,figcaption {font-size:10px;line-height:1.4;color:#536575}
.note {border-left:3px solid #bb650c;background:#fff6e9;padding:10px 12px;font-size:11px}.finding {border-left:3px solid #087d68;padding:8px 12px;background:#edf7f4}
table {border-collapse:collapse;width:100%;font-size:10px;margin:10px 0 13px} th {background:#edf2f6;text-align:left;color:#192e43;padding:7px 6px;border-bottom:1px solid #bac8d4} td {padding:6px;border-bottom:1px solid #e1e7ec;vertical-align:top} tbody tr:nth-child(even) {background:#f8fafc}
table.compact {font-size:9px} table.compact td,table.compact th {padding:4px 4px}
figure {margin:9px 0 12px} figure img {width:100%;display:block;object-fit:contain} figcaption {margin-top:5px}
ul {padding-left:18px;margin:8px 0 12px} li {margin:5px 0} code {font:10px Consolas,monospace;background:#f0f3f6;padding:1px 3px}
a {color:#235e9d}
footer {position:absolute;bottom:9mm;left:12mm;right:12mm;display:flex;justify-content:space-between;font-size:8px;color:#697a89;border-top:1px solid #d3dde5;padding-top:7px}
@page {size:A4 portrait;margin:12mm}
@media print {body {background:white}.page {width:186mm;height:273mm;padding:0;margin:0;box-shadow:none;break-after:page}.page:last-child {break-after:auto}footer {bottom:0;left:0;right:0}a {text-decoration:none}}
"""


def sims(scale, fleet, policy, rate, seed=None):
    return [r for r in SIM if r["scale"] == scale and r["fleet"] == fleet and r["policy"] == policy
            and r["rate_rps"] == rate and (seed is None or r["seed"] == seed)]


def fleets(scale, fleet, policy, rate, seed=None):
    return [r for r in FLEET if r["scale"] == scale and r["fleet"] == fleet and r["policy"] == policy
            and r["rate_rps"] == rate and (seed is None or r["seed"] == seed)]


def span(rows, key, scale=1.0, digits=1):
    values = [r[key] * scale for r in rows]
    low, high = f"{min(values):,.{digits}f}", f"{max(values):,.{digits}f}"
    return low if low == high else f"{low}-{high}"


def pct(value, digits=1):
    return f"{value * 100:.{digits}f}%"


def gain(policy_rows, base_rows, key="goodput_rps"):
    """Percent change of the policy over the base, paired by seed."""
    base = {r["seed"]: r[key] for r in base_rows}
    values = [100 * (r[key] / base[r["seed"]] - 1) for r in policy_rows if r["seed"] in base]
    return f"{min(values):.0f}-{max(values):.0f}%" if round(min(values)) != round(max(values)) else f"{min(values):.0f}%"


def difference(policy_rows, base_rows, key="goodput_rps"):
    """Signed percent difference of the policy from the base for single-seed pairs."""
    value = 100 * (policy_rows[0][key] / base_rows[0][key] - 1)
    return f"{abs(value):.1f}% {'higher' if value > 0 else 'lower'}"


def uncached_tps(engine, workers):
    """Engine prefill throughput for uncached tokens with every step spent on prefill."""
    return workers * engine["max_batched_tokens"] / (
        engine["step_fixed_ms"] + engine["max_batched_tokens"] * engine["step_prefill_ms_per_token"]) * 1000


# Figures ---------------------------------------------------------------------------------------

def fig_summary():
    groups = [("hetero", 350), ("hetero", 450), ("homo", 450), ("homo", 550)]
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 3.4))
    for ax, (key, title, scale) in zip(axes, [("goodput_rps", "Goodput (requests/s)", 1.0),
                                              ("slo_attainment", "SLO attainment (%)", 100.0)]):
        for offset, policy in ((-.2, WAW), (.2, PULSAR)):
            name = NAMES[policy]
            for index, (fleet, rate) in enumerate(groups):
                runs = fleets("half", fleet, policy, rate)
                values = [r[key] * scale for r in runs]
                mean = statistics.mean(values)
                ax.bar(index + offset, mean, .38, color=COLORS[name], label=name if index == 0 else None)
                if len(values) > 1:
                    ax.vlines(index + offset, min(values), max(values), color=INK, lw=1.2)
                reference = [r[key] * scale for r in sims("half", fleet, policy, rate)]
                ax.plot([index + offset] * len(reference), reference, "_", color=INK, ms=10, mew=1.5,
                        label="Simulator seeds" if index == 0 and policy == WAW else None)
        clean_axis(ax, title)
        ax.set_xticks(range(len(groups)), [f"{'Heterogeneous' if f == 'hetero' else 'Homogeneous'}\n{r} RPS"
                                           for f, r in groups], fontsize=8)
        if key == "slo_attainment":
            ax.set_ylim(75, 101)
    axes[0].legend(frameon=False, fontsize=7, loc="upper left")
    fig.tight_layout()
    save_figure(fig, "01-half-scale-summary")


def fig_backends():
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 3.3))
    for ax, rate in zip(axes, (350, 450)):
        for policy in (WAW, PULSAR):
            run = fleets("half", "hetero", policy, rate, 1)[0]
            points = sorted((b["gpu_workers"], b["ttft_p50_ms"] / 1000) for b in run["backends"])
            ax.plot([p[0] for p in points], [p[1] for p in points], "o", ms=4.5,
                    color=COLORS[NAMES[policy]], label=f"Fleet {NAMES[policy]}")
        clean_axis(ax, f"Per-backend TTFT p50, heterogeneous, {rate} RPS, seed 1", "Seconds")
        ax.set_xlabel("GPU workers in backend", fontsize=8)
        ax.set_xticks(range(2, 21, 2))
    axes[0].legend(frameon=False, fontsize=7)
    fig.tight_layout()
    save_figure(fig, "02-backend-size")


def fig_full_scale_sweep():
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 3.3))
    for ax, fleet in zip(axes, ("hetero", "homo")):
        for policy in (WAW, PULSAR):
            rates = sorted({r["rate_rps"] for r in SIM if r["scale"] == "full" and r["fleet"] == fleet
                            and r["policy"] == policy})
            low = [min(r["goodput_rps"] for r in sims("full", fleet, policy, rate)) for rate in rates]
            high = [max(r["goodput_rps"] for r in sims("full", fleet, policy, rate)) for rate in rates]
            color = COLORS[NAMES[policy]]
            ax.plot(rates, [(a + b) / 2 for a, b in zip(low, high)], "-o", ms=3.5, color=color, label=NAMES[policy])
            ax.vlines(rates, low, high, color=color, lw=3, alpha=.35)
        ax.plot([250, 1100], [250, 1100], ls=":", color=GREY, lw=1)
        clean_axis(ax, f"Simulator, full-scale engine, {'heterogeneous' if fleet == 'hetero' else 'homogeneous'}",
                   "Goodput (requests/s)")
        ax.set_xlabel("Nominal rate (requests/s)", fontsize=8)
    axes[0].legend(frameon=False, fontsize=7)
    fig.tight_layout()
    save_figure(fig, "03-simulator-full-scale")


def fig_weights():
    fig, ax = plt.subplots(figsize=(10.2, 3.2))
    gpus = DATA["backend_gpus"]
    for label, fleet, color, marker in (("c2-hetero-pulsar-waw-450-s1", "hetero", ORANGE, "o"),
                                        ("c2-homo-pulsar-waw-450-s1", "homo", BLUE, "s")):
        run = next(r for r in FLEET if r["label"] == label)
        weights = run["throttle"]["pylon_tps_end"]
        xs = [gpus[fleet][name] for name in weights]
        ys = [values["max_input_tps"] / gpus[fleet][name] / 1000 for name, values in weights.items()]
        ax.plot(xs, ys, marker, ms=4.5, color=color,
                label=f"{'Heterogeneous' if fleet == 'hetero' else 'Homogeneous'} fleet, Pulsar-WaW 450 RPS")
    ax.axhline(uncached_tps(ENGINES["half"], 1) / 1000, color=GREY, ls=":", lw=1.2,
               label="Engine prefill limit for uncached tokens")
    clean_axis(ax, "Pylon maximum input TPS per GPU worker at the end of the measured window",
               "Thousand tokens/s per GPU")
    ax.set_xlabel("GPU workers in backend", fontsize=8)
    ax.set_xticks(range(2, 21, 2))
    ax.legend(frameon=False, fontsize=7)
    fig.tight_layout()
    save_figure(fig, "04-pulsar-weights")


def cv(values):
    return statistics.pstdev(values) / statistics.mean(values)


def weight_stats(label, fleet):
    run = next(r for r in FLEET if r["label"] == label)
    gpus = DATA["backend_gpus"][fleet]
    per_gpu = [v["max_input_tps"] / gpus[name] for name, v in run["throttle"]["pylon_tps_end"].items()]
    return min(per_gpu), max(per_gpu), cv(per_gpu)


def run_table(scale, fleet, rates, seeds):
    rows = []
    for rate in rates:
        for seed in seeds:
            for policy in (WAW, PULSAR):
                run = fleets(scale, fleet, policy, rate, seed)[0]
                ref = sims(scale, fleet, policy, rate, seed)
                ref = ref[0] if ref else None
                rows.append([NAMES[policy], rate, seed,
                             f"{run['offered_rps']:.0f}",
                             f"{run['goodput_rps']:.1f}" + (f" / {ref['goodput_rps']:.1f}" if ref else ""),
                             pct(run["slo_attainment"]) + (f" / {pct(ref['slo_attainment'])}" if ref else ""),
                             pct(run["reuse"]),
                             f"{run['ttft_p99_ms'] / 1000:.1f} s",
                             f"{run['failed']:,}"])
    return rows


def sim_error(runs_by_key, policy, fleet):
    errors = []
    for (run_policy, rate), runs in runs_by_key.items():
        if run_policy != policy:
            continue
        for run in runs:
            reference = sims("half", fleet, policy, rate, run["seed"])[0]
            errors.append(100 * (reference["goodput_rps"] / run["goodput_rps"] - 1))
    return f"{min(errors):.0f}-{max(errors):.0f}%"


def report():
    fig_summary(); fig_backends(); fig_full_scale_sweep(); fig_weights()
    het = {(p, r): fleets("half", "hetero", p, r) for p in (WAW, PULSAR) for r in (350, 450)}
    hom = {(p, r): fleets("half", "homo", p, r) for p in (WAW, PULSAR) for r in (450, 550)}
    half, full = ENGINES["half"], ENGINES["full"]
    c2 = [r for r in FLEET if r["scale"] == "half"]
    max_throttle = max(r["throttle"]["max_throttled_fraction"] for r in c2)
    containers = c2[0]["throttle"]["containers"]

    summary_rows = []
    for fleet, rates, source in (("hetero", (350, 450), het), ("homo", (450, 550), hom)):
        for rate in rates:
            for policy in (WAW, PULSAR):
                runs = source[(policy, rate)]
                ref = sims("half", fleet, policy, rate)
                summary_rows.append([
                    "Heterogeneous" if fleet == "hetero" else "Homogeneous", rate, NAMES[policy], len(runs),
                    span(runs, "goodput_rps"), span(ref, "goodput_rps"),
                    span(runs, "slo_attainment", 100), span(runs, "reuse", 100),
                    span(runs, "ttft_p99_ms", .001)])
    page("Summary / Decision", "Pulsar-WaW wins on mixed backend sizes, not on equal ones",
        para("We ran WaW and Pulsar-WaW on the five-region development fleet in two shapes with the same 220 GPUs: "
             "a heterogeneous fleet of 20 backends with 2-20 GPUs each, and a homogeneous fleet with 11 GPUs per "
             "backend. Each fleet run is matched by a simulator run with the same workload, engine model, seed and "
             "routing configuration.", "lead") +
        para(f"On the heterogeneous fleet, Pulsar-WaW delivered {gain(het[(PULSAR, 450)], het[(WAW, 450)])} more "
             f"goodput than WaW at 450 requests/s across three seeds, and {gain(het[(PULSAR, 350)], het[(WAW, 350)])} "
             f"more at 350, with higher SLO attainment, cache reuse and lower tail latency in every pair. On the "
             f"homogeneous fleet Pulsar-WaW goodput was {difference(hom[(PULSAR, 450)], hom[(WAW, 450)])} than "
             f"WaW's at 450 and {difference(hom[(PULSAR, 550)], hom[(WAW, 550)])} at 550, and WaW had the lower "
             "tail latency.", "finding") +
        table(["Fleet", "RPS", "Policy", "Runs", "Goodput", "Sim goodput", "SLO %", "Reuse %", "TTFT p99 s"],
              summary_rows, "compact") +
        figure("01-half-scale-summary", "Bars are the mean of the fleet runs; black whiskers span the three seeds; "
               "dashes are the simulator runs for the same seeds. Half-scale engine.", 68) +
        para(f"No Pylon or MockDynamo container was CPU-throttled in any of these runs (maximum throttled fraction "
             f"{max_throttle:.3f} across {containers} containers per run), so the results reflect routing, not "
             "infrastructure limits.", "note"))

    regions = DATA["config"]["topology"]["regions"]
    pylon, client = DATA["config"]["pylon"], DATA["config"]["client"]
    growing = DATA["config"]["workload"]["growing"]
    pulsar, waw = DATA["policies"][PULSAR], DATA["policies"][WAW]
    page("Study design / What was held equal", "Two fleet shapes, one workload, matched seeds",
        table(["Region", "Stargates", "Heterogeneous GPU workers per backend", "Homogeneous"],
              [[r["name"], r["stargates"], ", ".join(str(g) for g in r["backend_gpu_workers"]), "11, 11, 11, 11"]
               for r in regions], "compact") +
        table(["Control", "Setting"], [
            ["Engine (half scale)", f"Batched mock engine shared by MockDynamo and the simulator: step = "
             f"{half['step_fixed_ms']} ms + {half['step_decode_ms_per_seq']} ms per decoding sequence + "
             f"{half['step_prefill_ms_per_token']} ms per prefill token; {half['kv_cache_capacity_tokens']:,} KV "
             f"tokens per GPU; {half['max_num_seqs']} sequences per GPU. Twice the step cost and half the KV of the "
             "full-scale engine, which moves saturation to rates the development nodes serve without CPU limits"],
            ["Engine (full scale)", f"{full['step_fixed_ms']} ms + {full['step_decode_ms_per_seq']} ms + "
             f"{full['step_prefill_ms_per_token']} ms; {full['kv_cache_capacity_tokens']:,} KV tokens per GPU "
             "(2026-10-06 runs, page 7)"],
            ["Pylon", f"Max engine concurrency = 25 x GPU workers; fallback-window input TPS, maximum weighting; "
             f"queue-mismatch admission {pylon['queue_mismatch']['min_delta_ms']:,} ms / "
             f"{pylon['queue_mismatch']['tolerance_factor']}; change-driven stats coalesced to "
             f"{pylon['stats_update_coalesce_ms']:.0f} ms; 2-CPU limit"],
            ["Client", f"{client['ttft_slo_ms']/1000:.0f} s TTFT SLO and maximum wait; "
             f"{client['timeout_ms']/1000:.0f} s timeout; up to {growing['max_turn_attempts']} attempts per turn"],
            ["Workload", f"Growing sessions: {growing['system_prompt_tokens']:,}-token system prompt, "
             f"{growing['user_tokens_min']}-{growing['user_tokens_max']:,} user and {growing['output_tokens_min']}-"
             f"{growing['output_tokens_max']} output tokens per turn, {growing['turns_min']}-{growing['turns_max']} "
             f"turns, {growing['think_time_mean_s']:.0f} s mean think time; 240 s warmup then 240 s measured"],
            ["Runs", "Heterogeneous: 350 and 450 RPS, seeds 1-3, policy order alternated. Homogeneous: 450 and "
             "550 RPS, seed 1. Every MockDC backend restarts before each run and all 15 Stargate replicas must "
             "report 20 backends before traffic starts"],
            ["Instrumentation", "One backend per node; CFS throttling counters and each Pylon's input TPS "
             "captured at the start and end of the measured window; record files checked line by line against "
             "the driver pods"],
        ], "compact") +
        table(["Policy", "Configuration"], [
            ["WaW", f"Affinity ring with {waw['cache_affinity_virtual_nodes']} virtual nodes per backend, "
             f"{waw['cache_affinity_backend_selection_count']} affine backend, {waw['cache_affinity_wait_ms']} ms "
             f"wait, max_queued {waw['max_queued']}, utilization comparator"],
            ["Pulsar-WaW", f"Rendezvous weights from maximum input TPS; {pulsar['cache_affinity_wait_ms']} ms affinity "
             f"wait; bands widen every {pulsar['band_widen_interval_ms']} ms; max_queued {pulsar['max_queued']}; "
             f"overflow only to free engine slots; 4 s queue bounds"],
        ], "compact"))

    page("Heterogeneous fleet / Every run", "Pulsar-WaW leads in all six seed pairs",
        table(["Policy", "RPS", "Seed", "Offered", "Goodput fleet / sim", "SLO fleet / sim", "Reuse",
               "TTFT p99", "Failures"], run_table("half", "hetero", (350, 450), (1, 2, 3)), "compact") +
        para(f"WaW on the fleet stays inside the simulator's seed range at both rates: "
             f"{span(het[(WAW, 450)], 'goodput_rps')} goodput at 450 against "
             f"{span(sims('half', 'hetero', WAW, 450), 'goodput_rps')} simulated. Pulsar-WaW runs below its "
             f"simulator prediction, {span(het[(PULSAR, 450)], 'goodput_rps')} against "
             f"{span(sims('half', 'hetero', PULSAR, 450), 'goodput_rps')} at 450, but its lowest seed still beats "
             f"WaW's best by {min(r['goodput_rps'] for r in het[(PULSAR, 450)]) - max(r['goodput_rps'] for r in het[(WAW, 450)]):.0f} "
             "requests/s.", "finding") +
        para("Failures are almost all client timeouts after three attempts. Each run also has a handful of HTTP 502 "
             "responses (at most a few dozen in about 80,000 requests) returned before a backend was selected.",
             "small"))

    w450, p450 = het[(WAW, 450)][0], het[(PULSAR, 450)][0]
    small = lambda run, limit: [b for b in run["backends"] if b["gpu_workers"] <= limit]
    small_ids = [name for name, count in DATA["backend_gpus"]["hetero"].items() if count <= 4]
    small_gpus = sum(DATA["backend_gpus"]["hetero"][name] for name in small_ids)
    small_counts = lambda run: (
        sum(b["succeeded"] for b in run["backends"] if b["id"] in small_ids),
        sum(run["failures_by_backend"].get(name, 0) for name in small_ids))
    small_p50 = lambda run: max(b["ttft_p50_ms"] for b in small(run, 4)) / 1000
    page("Heterogeneous fleet / Why", "WaW overloads the small backends",
        figure("02-backend-size", "TTFT p50 of each backend over the measured window against its GPU count, seed 1.", 76) +
        para(f"WaW's affinity ring gives every backend the same share of sessions whatever its size. At 450 "
             f"requests/s its 2-4 GPU backends reached up to {small_p50(w450):.1f} s TTFT p50 and evicted cached "
             f"sessions, so reuse across the fleet fell to {pct(w450['reuse'])}. Pulsar-WaW weights backends by "
             f"measured throughput and kept those backends at or below {small_p50(p450):.1f} s p50 with "
             f"{pct(p450['reuse'])} reuse.") +
        para(f"The 2-4 GPU backends hold {small_gpus} of the 220 GPUs. In the "
             f"measured window, WaW's sessions pinned to them stalled: {small_counts(w450)[0]:,} requests "
             f"succeeded there and {small_counts(w450)[1]:,} attempts hit the 30 s client timeout, so those "
             f"sessions made almost no progress. Under Pulsar-WaW the same backends completed {small_counts(p450)[0]:,} "
             f"requests with {small_counts(p450)[1]:,} timed-out attempts, and the larger backends carried the rest.",
             "finding"))

    hom_table = run_table("half", "homo", (450, 550), (1,))
    page("Homogeneous fleet / Control", "On equal backends WaW is as good or slightly better",
        table(["Policy", "RPS", "Seed", "Offered", "Goodput fleet / sim", "SLO fleet / sim", "Reuse",
               "TTFT p99", "Failures"], hom_table, "compact") +
        para(f"With every backend the same size, WaW's equal shares are already the right placement. Pulsar-WaW "
             f"goodput was {difference(hom[(PULSAR, 450)], hom[(WAW, 450)])} than WaW's at 450 and "
             f"{difference(hom[(PULSAR, 550)], hom[(WAW, 550)])} at 550, and Pulsar-WaW had the longer tail at both rates "
             f"({hom[(PULSAR, 450)][0]['ttft_p99_ms']/1000:.1f} s against {hom[(WAW, 450)][0]['ttft_p99_ms']/1000:.1f} s "
             "at 450). At 550 Pulsar-WaW also returned "
             f"{hom[(PULSAR, 550)][0]['failures'].get('overloaded_error', 0)} overloaded rejections.", "finding") +
        figure("03-simulator-full-scale", "Simulator sweep with the full-scale engine, seeds 1 and 2: lines join "
               "the seed midpoints, bars show the seed range. The dotted line is goodput equal to nominal rate.", 62) +
        para("The full-scale simulator shows the same split: on the heterogeneous fleet Pulsar-WaW holds goodput "
             "through 900 requests/s, where WaW has already collapsed, while on the homogeneous fleet WaW keeps up through 1,100 requests/s and "
             "Pulsar-WaW collapsed under one of the two seeds.", "small"))

    hmin, hmax, hcv = weight_stats("c2-hetero-pulsar-waw-450-s1", "hetero")
    omin, omax, ocv = weight_stats("c2-homo-pulsar-waw-450-s1", "homo")
    homo_pulsar = hom[(PULSAR, 450)][0]
    homo_waw = hom[(WAW, 450)][0]
    page("Pulsar weights / What the signal measures", "Maximum input TPS mostly measures cache hits",
        figure("04-pulsar-weights", "Each point is one backend's Pylon max_input_tps divided by its GPU workers. "
               "The dotted line is the half-scale engine's prefill limit for uncached tokens per GPU.", 70) +
        para(f"Per GPU, the measured maximum varied from {hmin/1000:.0f}k to {hmax/1000:.0f}k tokens/s across "
             f"heterogeneous backends (coefficient of variation {hcv:.2f}) and from {omin/1000:.0f}k to "
             f"{omax/1000:.0f}k across identical homogeneous backends ({ocv:.2f}). The engine can prefill at most "
             f"about {uncached_tps(half, 1)/1000:.0f}k uncached tokens/s per GPU, so most of the measured "
             "throughput is cached input that never reaches prefill.") +
        para("Total weight still grows with backend size, but sub-linearly: per GPU, the smallest backends "
             "reported about three times the throughput of the largest, so the weight favors small backends "
             "relative to their capacity. It is still far closer to capacity than WaW's equal shares, which kept "
             "the small backends serving at these rates instead of stalling. On equal backends the weight adds "
             "noise without information. That noise did not produce uneven placement in these runs: requests per backend varied by a coefficient of "
             f"{cv([b['succeeded'] for b in homo_pulsar['backends']]):.2f} under Pulsar-WaW and "
             f"{cv([b['succeeded'] for b in homo_waw['backends']]):.2f} under WaW at 450 requests/s. The cause of "
             "Pulsar-WaW's longer homogeneous tail is not isolated; its affinity wait and band widening are the "
             "next candidates.", "finding") +
        para("A weight based on uncached prefill throughput, or on configured capacity, would separate backend "
             "capacity from cache state. That is a follow-up, not something these runs measured.", "small"))

    full_rows = []
    for run in [r for r in FLEET if r["scale"] == "full"]:
        ref = sims("full", "hetero", run["policy"], run["rate_rps"], 1)
        ref = ref[0] if ref else None
        full_rows.append([NAMES[run["policy"]], run["rate_rps"], f"{run['offered_rps']:.0f}",
                          f"{run['goodput_rps']:.1f}" + (f" / {ref['goodput_rps']:.1f}" if ref else ""),
                          pct(run["slo_attainment"]) + (f" / {pct(ref['slo_attainment'])}" if ref else ""),
                          pct(run["reuse"]), f"{run['ttft_p99_ms']/1000:.1f} s", f"{run['failed']:,}",
                          f"{run['cpu']['pylon_peak_cores']:.2f}"])
    page("Full-scale engine / 2026-10-06", "Earlier full-scale runs: same ranking, unresolved collapse",
        table(["Policy", "RPS", "Offered", "Goodput fleet / sim", "SLO fleet / sim", "Reuse", "TTFT p99",
               "Failures", "Pylon peak cores"], full_rows, "compact") +
        para("These runs used the full-scale engine, one seed, a 1-CPU Pylon limit and no throttling counters, and "
             "backends could share a node after restarts. Pulsar-WaW led at 250 and 550 requests/s. At 900 both "
             "policies collapsed fleet-wide after about four minutes while the simulator predicted Pulsar-WaW "
             "would hold; Pylon ran close to its CPU limit, so infrastructure could not be ruled out. The "
             "half-scale campaign was designed to avoid that limit.") +
        para("Simulator references on this page come from the current simulator with seed 1. PowerOf2 has no "
             "simulator row in this sweep.", "small"))

    page("Conclusions / Evidence record", "Ship Pulsar-WaW for heterogeneous fleets",
        '<h2>What the data supports</h2>' + bullets([
            "On fleets with mixed backend sizes, Pulsar-WaW is clearly better than WaW at and near saturation, in "
            "every seed pair and in both the simulator and the fleet.",
            "On equal backends, WaW is as good or slightly better, with a shorter tail. Pulsar-WaW's advantage "
            "comes from capacity-aware placement and does not help when every backend is the same.",
            f"The simulator ranks the policies the same way as the fleet in every comparison. On the "
            f"heterogeneous fleet it predicts WaW within its seed range and overpredicts Pulsar-WaW by "
            f"{sim_error(het, PULSAR, 'hetero')}; on the homogeneous fleet it underpredicts Pulsar-WaW, most at 550 "
            f"requests/s ({sims('half', 'homo', PULSAR, 550, 1)[0]['goodput_rps']:.0f} simulated, "
            f"{hom[(PULSAR, 550)][0]['goodput_rps']:.0f} measured)."]) +
        '<h2>Next measurements</h2>' + bullets([
            "Isolate Pulsar-WaW's longer tail on equal backends: vary the affinity wait and band widening interval.",
            "Test a weight based on uncached prefill throughput or configured capacity instead of maximum input TPS.",
            "Repeat the 900 RPS full-scale comparison on larger MockDC nodes.",
            "Repeat the decisive cases on real engines before a production recommendation."]) +
        '<h2>Run record</h2>' + table(["Item", "Detail"], [
            ["Half-scale runs", "16 accepted runs on 2026-10-07; every record file matched its driver pod line by line"],
            ["Full-scale runs", "7 accepted runs on 2026-10-06; one earlier WaW 900 run excluded for driver "
             "open-file exhaustion"],
            ["Images", "Stargate, Pylon, MockDynamo and the fleet driver built from the reviewed routing stack"],
        ], "compact") +
        '<h2>Limitations</h2>' + para("The mock engine uses estimated step costs and is not calibrated against a real "
             "engine; cache reuse assumes a cached session covers its whole prompt. Each homogeneous rate has one "
             "fleet seed. Load balancers use an unseeded random generator, so simulator runs are not bit-for-bit "
             "reproducible.", "small") +
        table(["Bundle file", "Purpose"], [
            ["report.pdf / report.html", "Portable report and self-contained browser version"],
            ["results.json / results.csv", "Run-level values, per-backend tables, per-minute series, CPU, "
             "throttling and Pylon TPS snapshots"],
            ["graphs/*.svg / *.png", "Standalone figures"],
            ["extract_results.py / build_report.py / render_pdf.py", "Extraction, figures and rendering"],
        ], "compact"))

    assert len(PAGES) == 8
    doc = ('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" '
           'content="width=device-width, initial-scale=1"><title>Stargate routing performance | 2026-10-07</title>'
           '<style>' + STYLE + '</style></head><body>' + ''.join(PAGES) + '</body></html>')
    (ROOT / "report.html").write_text(doc)
    manifest = {"report_date": "2026-10-07", "pages": len(PAGES),
                "graphs": sorted(p.name for p in CHARTS.iterdir()),
                "results_sha256": hashlib.sha256((ROOT / "results.json").read_bytes()).hexdigest()}
    (ROOT / "report-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"Wrote {len(PAGES)} report pages and {len(list(CHARTS.glob('*.svg')))} figures")


if __name__ == "__main__":
    report()
