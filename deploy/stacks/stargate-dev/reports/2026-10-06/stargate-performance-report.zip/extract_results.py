"""Extract the 2026-10-06 simulator and dev-fleet results into results.json and results.csv.

Inputs (not shipped in the bundle; paths are relative to the campaign directory):
  sim/main-out.json, sim/low-out.json   simulator run summaries (seeds 1 and 2)
  bench.json, bench-main.json, bench-low.json   workload and policy configs
  fleet/<run>/{summary.json,*.jsonl}   fleet driver summaries and per-request records
  fleet/<run>.cpu.jsonl                kubelet CPU samples taken every 30 s
  fleet/campaign.log                   run start times
"""
from __future__ import annotations

import csv
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path

CAMPAIGN = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
POLICIES = {
    "waw": "wait-and-widen",
    "pulsar-waw": "pulsar-wait-and-widen",
    "power-of-n": "power-of-n",
    "round-robin": "round-robin",
}
FLEET_RUNS = [
    "c1-waw-250", "c1-pulsar-waw-250", "c1-waw-550", "c1-pulsar-waw-550",
    "c1-waw-900", "c1-pulsar-waw-900", "c1-power-of-n-250",
]
EXCLUDED_RUNS = {"c1-waw-900-nofile1024": "driver open-file soft limit 1,024 caused connect failures"}
NODE_SATURATED = 1.8
PYLON_SATURATED = 0.9


def quantile(values, q):
    if not values:
        return None
    values = sorted(values)
    return values[min(len(values) - 1, int(q * len(values)))]


def sim_rows():
    rows = []
    for name in ("main-out.json", "low-out.json"):
        for run in json.loads((CAMPAIGN / "sim" / name).read_text()):
            rows.append({
                "policy": run["policy"], "rate_rps": int(run["rate_rps"]), "seed": run["seed"],
                "offered": run["offered"], "succeeded": run["succeeded"], "good": run["good"],
                "offered_rps": run["offered"] / 240.0,
                "goodput_rps": run["goodput_rps"], "slo_attainment": run["slo_attainment"],
                "reuse": run["reused_input_token_fraction"], "cache_hit_rate": run["cache_hit_rate"],
                "ttft_p50_ms": run["ttft_ms"]["p50"], "ttft_p99_ms": run["ttft_ms"]["p99"],
                "failed_no_route": run["failed_no_route"],
                "failed_retries_exhausted": run["failed_retries_exhausted"],
                "failed_timeout": run["failed_timeout"],
                "cross_region_fraction": run["cross_region_fraction"],
                "backend_load_peak_to_mean": run["backend_load_peak_to_mean"],
                "backends": [
                    {"id": b["id"], "gpu_workers": b["gpu_workers"], "succeeded": b["succeeded"],
                     "ttft_p50_ms": b["ttft_ms"]["p50"], "ttft_p99_ms": b["ttft_ms"]["p99"],
                     "reuse": b["reused_input_token_fraction"]}
                    for b in run["backends"]
                ],
            })
    return rows


def run_starts():
    starts = {}
    for line in (CAMPAIGN / "fleet" / "campaign.log").read_text().splitlines():
        if "starting drivers at" in line:
            starts[line.split()[1].rstrip(":")] = int(line.split()[-1]) / 1000
    return starts


def cpu_stats(label, start, warmup, measure):
    window = (start + warmup, start + warmup + measure)
    nodes, pylon, mock, router, hub = [], [], [], [], []
    cluster_peak = defaultdict(float)
    for line in (CAMPAIGN / "fleet" / f"{label}.cpu.jsonl").read_text().splitlines():
        record = json.loads(line)
        if not window[0] <= record["t"] <= window[1]:
            continue
        mockdc = record["context"].startswith("mockdc-")
        if record["node_cpu_nanocores"] is not None:
            (nodes if mockdc else hub).append(record["node_cpu_nanocores"] / 1e9)
            cluster_peak[record["context"]] = max(cluster_peak[record["context"]], record["node_cpu_nanocores"] / 1e9)
        for key, value in record["pods"].items():
            if value is None:
                continue
            if key.endswith("/pylon"):
                pylon.append(value / 1e9)
            elif key.endswith("/mock-dynamo"):
                mock.append(value / 1e9)
            elif key.startswith("llm-request-router-") and "backend-router" not in key:
                router.append(value / 1e9)
    return {
        "samples": len(nodes),
        "mockdc_node_saturated_fraction": sum(v >= NODE_SATURATED for v in nodes) / max(len(nodes), 1),
        "mockdc_node_peak_cores": max(nodes, default=0.0),
        "pylon_mean_cores": statistics.mean(pylon) if pylon else 0.0,
        "pylon_peak_cores": max(pylon, default=0.0),
        "pylon_saturated_fraction": sum(v >= PYLON_SATURATED for v in pylon) / max(len(pylon), 1),
        "mock_dynamo_peak_cores": max(mock, default=0.0),
        "router_peak_cores": max(router, default=0.0),
        "hub_node_peak_cores": max(hub, default=0.0),
        "node_peak_cores_by_cluster": dict(cluster_peak),
    }


def per_minute(records):
    buckets = defaultdict(list)
    for record in records:
        buckets[int(record["arrival_us"] // 60_000_000)].append(record)
    series = []
    for minute in sorted(buckets):
        rows = buckets[minute]
        ok = [r for r in rows if r["status"] == 200 and r["ttft_us"] is not None and not r["error"]]
        ttft = [r["ttft_us"] / 1000 for r in ok]
        input_tokens = sum(r["input_tokens"] for r in ok)
        series.append({
            "minute": minute, "offered": len(rows), "succeeded": len(ok),
            "overloaded": sum(r["error"] == "overloaded_error" for r in rows),
            "timeouts": sum(r["error"] == "timeout" for r in rows),
            "reuse": (sum(r["reused_input_tokens"] or 0 for r in ok) / input_tokens) if input_tokens else None,
            "ttft_p50_ms": quantile(ttft, 0.5), "ttft_p99_ms": quantile(ttft, 0.99),
        })
    return series


def fleet_rows(gpus):
    bench = json.loads((CAMPAIGN / "bench.json").read_text())
    warmup, measure = bench["workload"]["warmup_s"], bench["workload"]["measure_s"]
    starts = run_starts()
    rows = []
    for label in FLEET_RUNS:
        name, rate = label.split("-", 1)[1].rsplit("-", 1)
        summary = json.loads((CAMPAIGN / "fleet" / label / "summary.json").read_text())[0]
        records = []
        for path in sorted((CAMPAIGN / "fleet" / label).glob("*.jsonl")):
            records.extend(json.loads(line) for line in path.read_text().splitlines())
        smallest = min(gpus, key=gpus.get)
        rows.append({
            "label": label, "policy": POLICIES[name], "rate_rps": int(rate), "seed": 1,
            "offered": summary["offered"], "succeeded": summary["succeeded"], "good": summary["good"],
            "offered_rps": summary["offered"] / measure,
            "goodput_rps": summary["goodput_rps"], "slo_attainment": summary["slo_attainment"],
            "reuse": summary["reused_input_token_fraction"],
            "ttft_p50_ms": summary["ttft_ms"]["p50"], "ttft_p99_ms": summary["ttft_ms"]["p99"],
            "e2e_p50_ms": summary["e2e_ms"]["p50"],
            "failures": summary["failures"], "failed": sum(summary["failures"].values()),
            "retried_requests": summary["retried_requests"],
            "abandoned_sessions": summary["abandoned_sessions"],
            "backends": [
                {"id": b["cluster_id"], "gpu_workers": b["gpu_workers"], "succeeded": b["succeeded"],
                 "ttft_p50_ms": b["ttft_ms"]["p50"], "ttft_p99_ms": b["ttft_ms"]["p99"],
                 "reuse": b["reused_input_token_fraction"]}
                for b in summary["backends"]
            ],
            "failures_by_backend": dict(Counter(
                r["cluster_id"] or "unrouted" for r in records
                if r["error"] and warmup * 1e6 <= r["arrival_us"] < (warmup + measure) * 1e6)),
            "cpu": cpu_stats(label, starts[label], warmup, measure),
            "minutes": per_minute(records),
            "smallest_backend_minutes": per_minute(
                [r for r in records if r["cluster_id"] == smallest]),
        })
    return rows


def main():
    gpus = json.loads((CAMPAIGN / "backend_gpus.json").read_text())
    bench = json.loads((CAMPAIGN / "bench.json").read_text())
    results = {
        "date": "2026-10-06",
        "config": {key: bench[key] for key in ("topology", "engine", "pylon", "stargate", "client", "workload")},
        "policies": {p["name"]: p["load_balancer"] for p in bench["policies"]},
        "backend_gpus": gpus,
        "simulator": sim_rows(),
        "fleet": fleet_rows(gpus),
        "excluded_fleet_runs": EXCLUDED_RUNS,
        "skipped_fleet_runs": {"c1-round-robin-250": "time budget",
                               "700 RPS pair, 150 RPS baselines": "time budget"},
    }
    (OUT / "results.json").write_text(json.dumps(results, indent=1))
    with (OUT / "results.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["source", "policy", "rate_rps", "seed", "metric", "value"])
        keys = ["offered_rps", "goodput_rps", "slo_attainment", "reuse", "ttft_p50_ms", "ttft_p99_ms"]
        for source in ("simulator", "fleet"):
            for row in results[source]:
                for key in keys:
                    writer.writerow([source, row["policy"], row["rate_rps"], row["seed"], key, row[key]])
    print(f"simulator rows {len(results['simulator'])}, fleet rows {len(results['fleet'])}")


if __name__ == "__main__":
    main()
