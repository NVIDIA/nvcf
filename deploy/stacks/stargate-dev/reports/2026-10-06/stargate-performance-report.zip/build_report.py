"""Build the 2026-10-06 Stargate routing report (HTML and figures) from results.json."""
from __future__ import annotations

import base64
import hashlib
import html
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
CHARTS = ROOT / "graphs"
CHARTS.mkdir(exist_ok=True)
INK = "#192e43"
MUTED = "#536575"
BLUE = "#2864ba"
GREEN = "#087d68"
ORANGE = "#bc620c"
PURPLE = "#7851a9"
GREY = "#8a99a8"
NAMES = {"wait-and-widen": "WaW", "pulsar-wait-and-widen": "Pulsar-WaW",
         "power-of-n": "PowerOf2", "round-robin": "Round-robin"}
COLORS = {"WaW": GREEN, "Pulsar-WaW": ORANGE, "PowerOf2": BLUE, "Round-robin": PURPLE}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
    "axes.labelcolor": INK, "text.color": INK, "xtick.color": MUTED,
    "ytick.color": MUTED, "axes.titleweight": "bold", "axes.titlesize": 10,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#b8c4ce", "grid.color": "#e4e9ef",
    "grid.linewidth": .65, "svg.fonttype": "none", "savefig.facecolor": "white"})

DATA = json.loads((ROOT / "results.json").read_text())
SIM = DATA["simulator"]
FLEET = DATA["fleet"]
GPUS = DATA["backend_gpus"]


def clean_axis(ax, title, ylabel=None):
    ax.set_title(title, loc="left", pad=11)
    if ylabel:
        ax.set_ylabel(ylabel)
    ax.set_axisbelow(True)
    ax.grid(axis="y")
    ax.tick_params(labelsize=8)


def save_figure(fig, name):
    for extension in ("svg", "png"):
        fig.savefig(CHARTS / f"{name}.{extension}", dpi=190, bbox_inches="tight", pad_inches=.13)
    plt.close(fig)


def figure(name, caption, height=None):
    encoded = base64.b64encode((CHARTS / (name + ".svg")).read_bytes()).decode()
    style = f' style="height:{height}mm"' if height else ""
    return (f'<figure><img alt="{html.escape(caption)}" src="data:image/svg+xml;base64,{encoded}"{style}>'
            f'<figcaption>{caption}</figcaption></figure>')


def table(headers, rows, cls=""):
    return ('<table class="' + cls + '"><thead><tr>' + ''.join('<th>' + html.escape(str(x)) + '</th>' for x in headers)
            + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join('<td>' + html.escape(str(x)) + '</td>' for x in row)
            + '</tr>' for row in rows) + '</tbody></table>')


def para(text, cls=""):
    return f'<p class="{cls}">{text}</p>'


def bullets(items):
    return '<ul>' + ''.join('<li>' + x + '</li>' for x in items) + '</ul>'


PAGES = []


def page(kicker, title, body):
    PAGES.append(f'<section class="page"><header><span>STARGATE / ROUTING PERFORMANCE</span><span>06 OCT 2026</span></header>'
                 f'<div class="kicker">{kicker}</div><h1>{title}</h1><main>{body}</main>'
                 f'<footer><span>Heterogeneous five-region fleet | Simulator and dev-cluster runs</span>'
                 f'<span>{len(PAGES)+1:02d}</span></footer></section>')


STYLE = """
* {box-sizing:border-box} body {margin:0;background:#e8edf2;color:#192e43;font:12px/1.48 Arial,Helvetica,sans-serif}
.page {width:210mm;height:297mm;padding:12mm;margin:18px auto;background:white;position:relative;box-shadow:0 3px 15px #22334422}
header {display:flex;justify-content:space-between;font-size:8px;letter-spacing:1.1px;border-bottom:1px solid #ccd7e1;padding-bottom:8px;color:#536575}
.kicker {font-size:9px;letter-spacing:1.2px;text-transform:uppercase;color:#087d68;margin-top:15px;font-weight:700}
h1 {font-size:25px;line-height:1.13;margin:5px 0 13px;letter-spacing:-.5px} h2 {font-size:15px;margin:16px 0 5px} h3 {font-size:12px;margin:13px 0 4px}
p {margin:7px 0 10px} .lead {font-size:14px;line-height:1.45} .small,figcaption {font-size:10px;line-height:1.4;color:#536575}
.note {border-left:3px solid #bb650c;background:#fff6e9;padding:10px 12px;font-size:11px}.finding {border-left:3px solid #087d68;padding:8px 12px;background:#edf7f4}
table {border-collapse:collapse;width:100%;font-size:10px;margin:10px 0 13px} th {background:#edf2f6;text-align:left;color:#192e43;padding:7px 6px;border-bottom:1px solid #bac8d4} td {padding:6px;border-bottom:1px solid #e1e7ec;vertical-align:top} tbody tr:nth-child(even) {background:#f8fafc}
table.compact {font-size:9px} table.compact td,table.compact th {padding:4px 4px}
figure {margin:9px 0 12px} figure img {width:100%;display:block;object-fit:contain} figcaption {margin-top:5px}
ul {padding-left:18px;margin:8px 0 12px} li {margin:5px 0} code {font:10px Consolas,monospace;background:#f0f3f6;padding:1px 3px}
a {color:#235e9d}
footer {position:absolute;bottom:9mm;left:12mm;right:12mm;display:flex;justify-content:space-between;font-size:8px;color:#697a89;border-top:1px solid #d3dde5;padding-top:7px}
@page {size:A4 portrait;margin:12mm}
@media print {body {background:white}.page {width:186mm;height:273mm;padding:0;margin:0;box-shadow:none;break-after:page}.page:last-child {break-after:auto}footer {bottom:0;left:0;right:0}a {text-decoration:none}}
"""


def sim(policy, rate, seed=None):
    rows = [r for r in SIM if r["policy"] == policy and r["rate_rps"] == rate and (seed is None or r["seed"] == seed)]
    assert rows, (policy, rate, seed)
    return rows


def fleet(policy, rate):
    rows = [r for r in FLEET if r["policy"] == policy and r["rate_rps"] == rate]
    assert len(rows) == 1, (policy, rate)
    return rows[0]


def span(rows, key, scale=1.0, digits=1):
    values = [r[key] * scale for r in rows]
    low, high = min(values), max(values)
    if f"{low:,.{digits}f}" == f"{high:,.{digits}f}":
        return f"{low:,.{digits}f}"
    return f"{low:,.{digits}f}-{high:,.{digits}f}"


def pct(value, digits=1):
    return f"{value * 100:.{digits}f}%"


def secs(ms, digits=2):
    return f"{ms / 1000:.{digits}f} s"


def sim_failures(row):
    return row["failed_no_route"] + row["failed_retries_exhausted"] + row["failed_timeout"]


# Figures ---------------------------------------------------------------------------------------

def fig_fleet_vs_sim():
    runs = FLEET
    labels = [f"{NAMES[r['policy']]} {r['rate_rps']}" for r in runs]
    x = np.arange(len(runs))
    fig, axes = plt.subplots(1, 3, figsize=(10.2, 3.5))
    panels = [("goodput_rps", "Goodput (requests/s)", 1.0), ("reuse", "Input-token reuse (%)", 100.0),
              ("ttft_p99_ms", "TTFT p99 (s)", 0.001)]
    for ax, (key, title, scale) in zip(axes, panels):
        fleet_values = [r[key] * scale for r in runs]
        sim_values = [sim(r["policy"], r["rate_rps"], 1)[0][key] * scale for r in runs]
        colors = [COLORS[NAMES[r["policy"]]] for r in runs]
        ax.bar(x - .2, sim_values, .38, color="#d5dde5", label="Simulator, seed 1")
        ax.bar(x + .2, fleet_values, .38, color=colors, label="Fleet")
        clean_axis(ax, title)
        ax.set_xticks(x, labels, fontsize=7, rotation=55, ha="right", rotation_mode="anchor")
    axes[0].legend(frameon=False, fontsize=7, loc="upper left")
    fig.tight_layout()
    save_figure(fig, "01-fleet-vs-simulator")


def fig_simulator():
    fig, axes = plt.subplots(1, 3, figsize=(10.2, 3.3))
    panels = [("goodput_rps", "Goodput (requests/s)", 1.0), ("slo_attainment", "SLO attainment (%)", 100.0),
              ("ttft_p99_ms", "TTFT p99 (s)", 0.001)]
    for ax, (key, title, scale) in zip(axes, panels):
        for policy in NAMES:
            rates = sorted({r["rate_rps"] for r in SIM if r["policy"] == policy})
            low = [min(r[key] for r in sim(policy, rate)) * scale for rate in rates]
            high = [max(r[key] for r in sim(policy, rate)) * scale for rate in rates]
            mid = [(a + b) / 2 for a, b in zip(low, high)]
            color = COLORS[NAMES[policy]]
            ax.plot(rates, mid, "-o", color=color, ms=3.5, lw=1.4, label=NAMES[policy])
            ax.vlines(rates, low, high, color=color, lw=3, alpha=.35)
        clean_axis(ax, title)
        ax.set_xlabel("Nominal rate (requests/s)", fontsize=8)
    axes[0].plot([150, 900], [150, 900], ls=":", color=GREY, lw=1)
    axes[0].legend(frameon=False, fontsize=7)
    fig.tight_layout()
    save_figure(fig, "02-simulator-sweep")


def fig_backends():
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 3.4))
    for ax, rate in zip(axes, (250, 550)):
        for policy in ("wait-and-widen", "pulsar-wait-and-widen"):
            run = fleet(policy, rate)
            points = sorted((b["gpu_workers"], b["ttft_p50_ms"] / 1000) for b in run["backends"])
            ax.plot([p[0] for p in points], [p[1] for p in points], "o", ms=4.5,
                    color=COLORS[NAMES[policy]], label=f"Fleet {NAMES[policy]}")
        reference = sim("wait-and-widen", rate, 1)[0]
        points = sorted((b["gpu_workers"], b["ttft_p50_ms"] / 1000) for b in reference["backends"])
        ax.plot([p[0] for p in points], [p[1] for p in points], "x", ms=4.5, color=GREY, label="Simulator WaW")
        clean_axis(ax, f"Per-backend TTFT p50 at {rate} requests/s", "Seconds")
        ax.set_xlabel("GPU workers in backend", fontsize=8)
        ax.set_xticks(range(2, 21, 2))
    axes[0].legend(frameon=False, fontsize=7)
    fig.tight_layout()
    save_figure(fig, "03-backend-size")


def fig_smallest_backend():
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 3.1))
    for policy in ("wait-and-widen", "pulsar-wait-and-widen"):
        minutes = fleet(policy, 250)["smallest_backend_minutes"]
        color = COLORS[NAMES[policy]]
        axes[0].plot([m["minute"] + .5 for m in minutes], [m["ttft_p50_ms"] / 1000 for m in minutes],
                     "-o", ms=3.5, color=color, label=NAMES[policy])
        axes[1].plot([m["minute"] + .5 for m in minutes], [m["reuse"] * 100 for m in minutes],
                     "-o", ms=3.5, color=color, label=NAMES[policy])
    clean_axis(axes[0], "2-GPU backend TTFT p50, 250 requests/s", "Seconds")
    clean_axis(axes[1], "2-GPU backend input-token reuse", "%")
    for ax in axes:
        ax.axvspan(4, 8, color="#edf2f6", zorder=0)
        ax.set_xlabel("Minute of run (shaded: measured window)", fontsize=8)
    axes[0].legend(frameon=False, fontsize=7)
    fig.tight_layout()
    save_figure(fig, "04-smallest-backend")


def fig_collapse():
    fig, axes = plt.subplots(1, 3, figsize=(10.2, 3.3))
    for policy in ("wait-and-widen", "pulsar-wait-and-widen"):
        minutes = fleet(policy, 900)["minutes"]
        color = COLORS[NAMES[policy]]
        xs = [m["minute"] + .5 for m in minutes]
        axes[0].plot(xs, [m["reuse"] * 100 for m in minutes], "-o", ms=3.5, color=color, label=NAMES[policy])
        axes[1].plot(xs, [m["ttft_p50_ms"] / 1000 for m in minutes], "-o", ms=3.5, color=color)
        axes[2].plot(xs, [m["overloaded"] / 60 for m in minutes], "-o", ms=3.5, color=color)
        reference = sim(policy, 900, 1)[0]
        axes[0].axhline(reference["reuse"] * 100, color=color, ls=":", lw=1)
    clean_axis(axes[0], "Input-token reuse (%)")
    clean_axis(axes[1], "TTFT p50 (s)")
    clean_axis(axes[2], "Overloaded rejections per second")
    for ax in axes:
        ax.axvspan(4, 8, color="#edf2f6", zorder=0)
        ax.set_xlabel("Minute of run", fontsize=8)
    axes[0].legend(frameon=False, fontsize=7, loc="lower left")
    fig.tight_layout()
    save_figure(fig, "05-high-load-collapse")


def share(part, total):
    return f"all {total:,} of its" if part == total else f"{part:,} of its {total:,}"


def small_backend(run):
    return min(run["backends"], key=lambda b: b["gpu_workers"])


def small_p50(run):
    return small_backend(run)["ttft_p50_ms"]


def small_cluster():
    name = min(GPUS, key=GPUS.get)
    return name.rsplit("-backend-", 1)[0]


def waw550_small_timeouts():
    run = fleet("wait-and-widen", 550)
    assert sum(run["failures_by_backend"].values()) == run["failed"]
    return sum(count for name, count in run["failures_by_backend"].items() if GPUS.get(name, 99) <= 4)


# Pages -----------------------------------------------------------------------------------------

def summary_rows():
    rows = []
    for run in FLEET:
        reference = sim(run["policy"], run["rate_rps"], 1)[0]
        rows.append([NAMES[run["policy"]], run["rate_rps"],
                     f"{run['offered_rps']:.0f} / {reference['offered_rps']:.0f}",
                     f"{run['goodput_rps']:.1f} / {reference['goodput_rps']:.1f}",
                     f"{pct(run['slo_attainment'])} / {pct(reference['slo_attainment'])}",
                     f"{pct(run['reuse'])} / {pct(reference['reuse'])}",
                     f"{secs(run['ttft_p99_ms'])} / {secs(reference['ttft_p99_ms'])}",
                     f"{run['failed']:,}"])
    return rows


def report():
    fig_fleet_vs_sim(); fig_simulator(); fig_backends(); fig_smallest_backend(); fig_collapse()
    waw250, pul250 = fleet("wait-and-widen", 250), fleet("pulsar-wait-and-widen", 250)
    waw550, pul550 = fleet("wait-and-widen", 550), fleet("pulsar-wait-and-widen", 550)
    waw900, pul900 = fleet("wait-and-widen", 900), fleet("pulsar-wait-and-widen", 900)
    pon250 = fleet("power-of-n", 250)
    small_waw = waw250["smallest_backend_minutes"]
    small_pul = pul250["smallest_backend_minutes"]
    sim_pul900 = sim("pulsar-wait-and-widen", 900)
    sim_waw900 = sim("wait-and-widen", 900)
    small_timeouts = waw550_small_timeouts()
    high_peaks = [r["cpu"]["pylon_peak_cores"] for r in FLEET if r["rate_rps"] >= 550]

    page("Summary / Decision", "Pulsar-WaW leads; the fleet breaks earlier than the simulator",
        para("We compared WaW and Pulsar-WaW, with PowerOf2 and round-robin as baselines, on a heterogeneous "
             "fleet of 20 backends with 2-20 GPUs each (220 GPUs). The discrete-event simulator and the "
             "five-region dev clusters ran the same workload, engine model and routing configuration.", "lead") +
        para(f"Pulsar-WaW matched or beat WaW at every rate on both the simulator and the fleet. At 550 requests/s "
             f"on the fleet it met the SLO for {pct(pul550['slo_attainment'])} of requests with "
             f"{pct(pul550['reuse'])} reuse; WaW reached {pct(waw550['slo_attainment'])} with "
             f"{pct(waw550['reuse'])} reuse and {waw550['failed']} timeouts.", "finding") +
        table(["Policy", "Nominal RPS", "Offered RPS fleet / sim", "Goodput fleet / sim", "SLO met",
               "Reuse", "TTFT p99", "Fleet failures"], summary_rows(), "compact") +
        figure("01-fleet-vs-simulator", "Fleet runs (colored) against simulator seed 1 (grey) for the same "
               "policy and nominal rate. Goodput counts successful requests whose TTFT met the 10 s SLO, per "
               "second of the 240 s measured window.", 70) +
        para("Up to 550 requests/s, fleet SLO attainment, reuse and tail latency match the simulator closely for "
             "Pulsar-WaW, and for PowerOf2 at 250; fleet goodput is up to 5% lower because fewer turns were "
             "offered. WaW does worse on the fleet than simulated because its smallest backends overload sooner. "
             f"At 900 requests/s both affinity policies collapse on the fleet; the simulator shows WaW degrading "
             f"({span(sim('wait-and-widen', 900), 'slo_attainment', 100)}% SLO) and Pulsar-WaW holding "
             f"{span(sim('pulsar-wait-and-widen', 900), 'slo_attainment', 100)}%. Each fleet point is one run.", "note"))

    regions = DATA["config"]["topology"]["regions"]
    engine, pylon, client = DATA["config"]["engine"], DATA["config"]["pylon"], DATA["config"]["client"]
    growing = DATA["config"]["workload"]["growing"]
    pulsar = DATA["policies"]["pulsar-wait-and-widen"]
    waw = DATA["policies"]["wait-and-widen"]
    page("Study design / What was held equal", "One workload, one engine model, two environments",
        table(["Region", "Stargates", "Backend GPU workers"],
              [[r["name"], r["stargates"], ", ".join(str(g) for g in r["backend_gpu_workers"])] for r in regions], "compact") +
        table(["Control", "Setting"], [
            ["Engine model", f"Batched mock engine shared by MockDynamo and the simulator: {engine['max_num_seqs']} sequences "
             f"and {engine['max_batched_tokens']:,} batched tokens per GPU worker; step = {engine['step_fixed_ms']} ms + "
             f"{engine['step_decode_ms_per_seq']} ms per decoding sequence + {engine['step_prefill_ms_per_token']} ms per "
             f"prefill token; {engine['kv_cache_capacity_tokens']:,} KV tokens per GPU; perfect KV routing between workers"],
            ["Pylon", f"Max engine concurrency = 25 x GPU workers; fallback-window input TPS (maximum, initial "
             f"{pylon['input_tps']['initial']:,.0f}); queue-mismatch admission {pylon['queue_mismatch']['min_delta_ms']:,} ms "
             f"/ {pylon['queue_mismatch']['tolerance_factor']}; change-driven stats coalesced to "
             f"{pylon['stats_update_coalesce_ms']:.0f} ms; engine stats stream disabled"],
            ["Client", f"{client['ttft_slo_ms']/1000:.0f} s TTFT SLO and maximum wait; {client['timeout_ms']/1000:.0f} s "
             f"timeout; up to {growing['max_turn_attempts']} attempts per turn, {growing['retry_backoff_s']:.0f} s backoff"],
            ["Workload", f"Growing sessions: {growing['system_prompt_tokens']:,}-token system prompt, "
             f"{growing['user_tokens_min']}-{growing['user_tokens_max']:,} user tokens and "
             f"{growing['output_tokens_min']}-{growing['output_tokens_max']} output tokens per turn, "
             f"{growing['turns_min']}-{growing['turns_max']} turns, {growing['think_time_mean_s']:.0f} s mean think time; "
             f"each turn's prompt includes all earlier turns and outputs"],
            ["Timing", "240 s warmup, then 240 s measured; equal traffic from all five regions"],
            ["Reset", "Fleet: all MockDC backends restarted before each run, then 20 of 20 registered on all 15 Stargate pods"],
        ], "compact") +
        table(["Policy", "Configuration"], [
            ["WaW", f"Cache-affinity ring ({waw['cache_affinity_virtual_nodes']} virtual nodes per backend), "
             f"{waw['cache_affinity_backend_selection_count']} affine backend, {waw['cache_affinity_wait_ms']} ms wait, "
             f"max_queued {waw['max_queued']}, utilization comparator"],
            ["Pulsar-WaW", f"Maximum-TPS weighting; {pulsar['cache_affinity_wait_ms']} ms affinity wait; bands widen every "
             f"{pulsar['band_widen_interval_ms']} ms (1, 2, 4 ... backends); max_queued {pulsar['max_queued']}; overflow "
             f"only to free engine slots (fallback_max_queued {pulsar['fallback_max_queued']}); 4 s queue bounds"],
            ["PowerOf2", "Two random samples, TTFT comparator"],
            ["Round-robin", "No load or cache signal (simulator only)"],
        ], "compact") +
        para("Nominal rate sets the session arrival rate; later turns wait for the previous response plus think "
             "time. Slow responses therefore lower the offered rate, so every table reports offered rate next to "
             "goodput. Reuse is reused input tokens over input tokens of successful requests. Simulator results use "
             "seeds 1 and 2; fleet results use seed 1 and compare against simulator seed 1.", "small"))

    sim_table = []
    for policy in NAMES:
        for rate in sorted({r["rate_rps"] for r in SIM if r["policy"] == policy}):
            rows = sim(policy, rate)
            sim_table.append([NAMES[policy], rate, span(rows, "offered_rps", digits=0), span(rows, "goodput_rps"),
                              span(rows, "slo_attainment", 100), span(rows, "reuse", 100),
                              span(rows, "ttft_p50_ms", .001, 2), span(rows, "ttft_p99_ms", .001, 1),
                              span([{"f": sim_failures(r)} for r in rows], "f", digits=0)])
    page("Simulator / Seeds 1 and 2", "Pulsar-WaW keeps reuse as load rises",
        figure("02-simulator-sweep", "Lines join the midpoints of the two seeds; vertical bars show the seed range. "
               "The dotted line in the goodput panel is goodput equal to nominal rate.", 66) +
        table(["Policy", "RPS", "Offered", "Goodput", "SLO %", "Reuse %", "TTFT p50 s", "TTFT p99 s", "Failures"],
              sim_table, "compact") +
        para(f"At 900 requests/s, Pulsar-WaW sustains {span(sim_pul900, 'goodput_rps')} goodput with "
             f"{span(sim_pul900, 'reuse', 100)}% reuse; WaW falls to {span(sim_waw900, 'goodput_rps')} with "
             f"{span(sim_waw900, 'reuse', 100)}% reuse. PowerOf2 and round-robin ignore cache placement and lose "
             "capacity early on this cache-heavy workload: PowerOf2 falls short at 250 requests/s and round-robin "
             "already at 150.", "finding") +
        para("Ranges are the two observed seeds, not confidence intervals.", "small"))

    page("Fleet / Matched against the simulator", "The fleet agrees below saturation",
        para(f"Pulsar-WaW agrees with the simulator at 250 and 550 requests/s, and PowerOf2 at 250. At 250, Pulsar-WaW "
             f"reached {pul250['goodput_rps']:.1f} goodput and {pct(pul250['reuse'])} reuse on the fleet against "
             f"{sim('pulsar-wait-and-widen', 250, 1)[0]['goodput_rps']:.1f} and "
             f"{pct(sim('pulsar-wait-and-widen', 250, 1)[0]['reuse'])} simulated; PowerOf2 reached "
             f"{pon250['goodput_rps']:.1f} against {sim('power-of-n', 250, 1)[0]['goodput_rps']:.1f}.") +
        para(f"Fleet goodput at 550 is about 5% below the simulator because fewer turns were offered: "
             f"{pul550['offered_rps']:.0f} requests/s for Pulsar-WaW against "
             f"{sim('pulsar-wait-and-widen', 550, 1)[0]['offered_rps']:.0f} simulated. Real network and streaming "
             f"time lengthen each turn. Pulsar-WaW still met the SLO for {pct(pul550['slo_attainment'])} of what was "
             "offered.") +
        figure("03-backend-size", "TTFT p50 of each backend against its GPU count. Each point is one backend "
               "over the measured window; crosses are simulator seed 1 under WaW.", 78) +
        para(f"Small backends are the pressure point. WaW's affinity ring gives each backend an equal share of "
             f"sessions whatever its size. At 550 requests/s its 2-GPU backend ran at {secs(small_p50(waw550), 1)} "
             f"p50 on the fleet and {secs(small_p50(sim('wait-and-widen', 550, 1)[0]), 1)} in the simulator, and "
             f"the 2-4 GPU backends produced {share(small_timeouts, waw550['failed'])} fleet timeouts. Pulsar-WaW "
             f"also slows its 2-GPU backend ({secs(small_p50(pul550), 1)} fleet, "
             f"{secs(small_p50(sim('pulsar-wait-and-widen', 550, 1)[0]), 1)} simulated) but completed "
             f"{small_backend(pul550)['succeeded']:,} requests there in the measured window against "
             f"{small_backend(waw550)['succeeded']:,} for WaW, with no timeouts.", "finding"))

    first_bad = next(m for m in small_waw if m["ttft_p50_ms"] > 1000)
    page("Fleet / Small backends", "WaW tips small backends into cache thrash",
        figure("04-smallest-backend", "The 2-GPU backend, one point per minute of the 250 requests/s runs. Arrival "
               "minute 4 is the start of the measured window.", 66) +
        para(f"Under WaW the 2-GPU backend served the simulated behavior for three minutes, then switched state in "
             f"minute {first_bad['minute']}: TTFT p50 rose to {secs(first_bad['ttft_p50_ms'], 1)} and reuse fell to "
             f"{pct(first_bad['reuse'], 0)}. It never recovered. Under Pulsar-WaW the same backend stayed at "
             f"{secs(max(m['ttft_p50_ms'] for m in small_pul[3:]), 2)} p50 or better with "
             f"{pct(min(m['reuse'] for m in small_pul[3:]), 0)}-{pct(max(m['reuse'] for m in small_pul[3:]), 0)} "
             "reuse.") +
        para("This matches the bistable small-backend behavior first seen in the simulator: once evictions start, "
             "reuse falls, prefill work grows and the backend stays overloaded. The simulator stayed in the good "
             "state at 250 under both seeds; the fleet tipped over. The trigger is not isolated: both policies sent "
             f"this backend about the same number of requests over the run ({sum(m['offered'] for m in small_pul):,} "
             f"under Pulsar-WaW, {sum(m['offered'] for m in small_waw):,} under WaW), so the difference is in how "
             "each policy reacts once the backend slows.", "finding") +
        para(f"CPU is not the cause: the nodes hosting this backend peaked at "
             f"{waw250['cpu']['node_peak_cores_by_cluster'][small_cluster()]:.2f} cores during the WaW measured "
             "window, on 2-vCPU nodes.", "small"))

    cpu_rows = [[NAMES[r["policy"]], r["rate_rps"], f"{r['cpu']['pylon_mean_cores']:.2f}",
                 f"{r['cpu']['pylon_peak_cores']:.2f}", pct(r['cpu']['mockdc_node_saturated_fraction'], 0),
                 f"{r['cpu']['mockdc_node_peak_cores']:.2f}", f"{r['cpu']['router_peak_cores']:.2f}"] for r in FLEET]
    collapse = next(m for m in pul900["minutes"] if m["reuse"] < .5)
    page("Fleet / 900 requests/s", "Both affinity policies collapse on the fleet",
        figure("05-high-load-collapse", "Per-minute fleet values at a nominal 900 requests/s. Dotted lines in the "
               "reuse panel are the simulator seed-1 run-level reuse for each policy.", 66) +
        para(f"Pulsar-WaW held {pct(pul900['minutes'][3]['reuse'], 0)} reuse through minute 3, then reuse fell "
             f"fleet-wide to {pct(collapse['reuse'], 0)} in minute {collapse['minute']} and Stargate began rejecting "
             f"requests as overloaded in all five regions. Measured goodput was {pul900['goodput_rps']:.0f} against "
             f"{sim('pulsar-wait-and-widen', 900, 1)[0]['goodput_rps']:.0f} simulated. WaW collapsed more gradually "
             f"to {waw900['goodput_rps']:.0f} goodput, against {sim('wait-and-widen', 900, 1)[0]['goodput_rps']:.0f} "
             "simulated.") +
        table(["Policy", "RPS", "Pylon mean cores", "Pylon peak", "MockDC node samples >= 1.8 cores",
               "MockDC node peak", "Stargate peak"], cpu_rows, "compact") +
        para("The cause is not confirmed. The fleet had more latency and jitter than the model: real "
             "cross-region links, token streaming through reverse tunnels and Pylon CPU. Pylon peaked at "
             f"{min(high_peaks):.2f}-{max(high_peaks):.2f} cores against a 1-CPU limit in every run from 550 upward, which is consistent with throttling on the "
             "busiest backends; throttling counters were not captured for those runs. MockDC nodes are 2-vCPU "
             "t3.medium instances.", "note"))

    page("Conclusions / Evidence record", "Ship candidate: Pulsar-WaW with the tested configuration",
        '<h2>What the data supports</h2>' + bullets([
            "Pulsar-WaW (maximum-TPS weighting, 300 ms affinity wait, 300 ms band widening, max_queued 4, overflow "
            "only to free engine slots) is the better of the two shippable policies on both environments.",
            "Small backends are WaW's weakness on a heterogeneous fleet: they overload first and, once they start "
            "evicting, do not recover within a run.",
            "The simulator is a reliable guide below saturation. It is optimistic near saturation, where the fleet "
            "tips into collapse earlier."]) +
        '<h2>Next measurements</h2>' + bullets([
            "Repeat 700 and 900 requests/s on larger MockDC nodes with Pylon CPU headroom and throttling counters, "
            "to separate infrastructure limits from routing behavior.",
            "Add a second fleet seed and a 700 requests/s pair to locate the fleet collapse point.",
            "Run round-robin and the 150 requests/s baselines on the fleet; they were skipped for time.",
            "Repeat the decisive cases on real engines before a production recommendation."]) +
        '<h2>Run record</h2>' + table(["Item", "Detail"], [
            ["Fleet runs", f"{len(FLEET)} accepted runs, seed 1, one run per policy and rate"],
            ["Excluded", "One earlier WaW 900 run: the driver's open-file soft limit of 1,024 caused about 52,000 "
             "connect failures. Rerun with the limit raised to 524,288."],
            ["Skipped", "Round-robin 250, the 700 pair and the 150 baselines, to fit the time budget"],
            ["Interruptions", "A short loss of Kubernetes API access interrupted one backend reset; the run was "
             "restarted from a clean reset"],
            ["Images", "Stargate, Pylon and MockDynamo built from one commit of the open routing PR stack; "
             "MockDynamo adds the stats-stream switch from this PR"],
        ], "compact") +
        '<h2>Limitations</h2>' + para("MockDynamo models batching, chunked prefill and per-worker KV caching with "
             "estimated step costs; it is not calibrated against a real engine. Cache reuse assumes a cached "
             "session covers its whole prompt; there is no block-level prefix matching. Load balancers use an "
             "unseeded random generator, so simulator runs are not bit-for-bit reproducible. Fleet CPU samples "
             "come from the kubelet summary API every 30 s.", "small") +
        table(["Bundle file", "Purpose"], [
            ["report.pdf / report.html", "Portable report and self-contained browser version"],
            ["results.json / results.csv", "Run-level values, per-backend tables, per-minute series and CPU statistics"],
            ["graphs/*.svg / *.png", "Standalone figures"],
            ["extract_results.py / build_report.py / render_pdf.py", "Extraction, figures and rendering"],
        ], "compact"))

    assert len(PAGES) == 7
    doc = ('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" '
           'content="width=device-width, initial-scale=1"><title>Stargate routing performance | 2026-10-06</title>'
           '<style>' + STYLE + '</style></head><body>' + ''.join(PAGES) + '</body></html>')
    (ROOT / "report.html").write_text(doc)
    manifest = {"report_date": "2026-10-06", "pages": len(PAGES),
                "graphs": sorted(p.name for p in CHARTS.iterdir()),
                "results_sha256": hashlib.sha256((ROOT / "results.json").read_bytes()).hexdigest()}
    (ROOT / "report-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"Wrote {len(PAGES)} report pages and {len(list(CHARTS.glob('*.svg')))} figures")


if __name__ == "__main__":
    report()
