Stargate routing performance - heterogeneous fleet report, 2026-10-06

Open report.pdf for the 7-page report, or report.html for its self-contained
browser version. Five figures are available in graphs/ as PNG and SVG.

Scope
The report uses only the 2026-10-06 runs: the discrete-event routing
simulator (seeds 1 and 2) and the five-region development fleet (seed 1).
Both use the same heterogeneous topology of 20 backends with 2-20 GPU
workers, the same batched mock engine, Pylon and Stargate settings, and the
same growing-session workload. Earlier campaigns are not included.

Data
results.json holds run-level values, per-backend tables, per-minute fleet
series, CPU statistics, the workload and policy configuration, and the
backend GPU map. results.csv contains the run-level metrics in long form.
Simulator ranges are the two observed seeds, not confidence intervals.
Each fleet value is a single run.

Rebuild
  python3 extract_results.py      (needs the raw campaign directory)
  python3 build_report.py
  python3 render_pdf.py --expected-pages 7

extract_results.py reads simulator summaries, fleet driver records and CPU
samples that are not shipped here; results.json is its output.
build_report.py needs Matplotlib and NumPy (Python 3.10, Matplotlib 3.10.9).
render_pdf.py needs Chromium and pdfinfo. It discovers chromium or
google-chrome on PATH, or accepts REPORT_CHROMIUM for the executable and
REPORT_CHROMIUM_LIBRARIES for an extra library directory.

Production recommendation remains pending real-engine QA.
