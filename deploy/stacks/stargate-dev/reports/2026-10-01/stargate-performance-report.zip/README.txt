Stargate routing performance - final report, 2026-10-01

Open report.pdf for the 10-page report, or report.html for its self-contained
browser version. Eight figures are available individually in graphs/ as PNG
and SVG. The report covers the five-region deployment and includes a separate
two-region historical appendix.

Evidence basis
The original benchmark artifacts were deleted. This bundle reconstructs the
published summaries preserved in PR #1519 and PR #1002. It does not recreate
raw request timelines, telemetry, confidence intervals or per-repeat samples.
Source PR JSON snapshots are included. Non-measurement references to an
internal repository were redacted in these public copies; the measurement
tables and their line positions are unchanged. Values preserve published rounding;
derived percent changes and normalized error/retry rates are labeled.
The duplicated mean/maximum tables describe one pair, not two replications.

Data
results.json includes scoped datasets, measurement definitions and source-cell
provenance. results.csv contains the same normalized metrics in long form.
Ranges are observed min/max across two repeats, not confidence intervals.
The two application builds and the two topologies remain separate.

Rebuild
  python3 extract_results.py
  python3 build_report.py
  python3 render_pdf.py --expected-pages 10

build_report.py needs Matplotlib and NumPy. This report used Python 3.10 and
Matplotlib 3.10.9. render_pdf.py needs Chromium and pdfinfo. It discovers
chromium/google-chrome on PATH, or accepts REPORT_CHROMIUM for the executable.
Set REPORT_CHROMIUM_LIBRARIES only if a custom library directory is needed.
You can also print report.html to A4 PDF from a browser with browser
headers/footers off. The HTML embeds its figures and has no external image
or font dependencies.

Review
Source-cell and numeric conversions were checked independently against the
preserved PR bodies. All 10 PDF pages were visually checked. These checks
validate this report against its summaries, not the deleted measurement files.
Production recommendation remains pending real-engine QA.
