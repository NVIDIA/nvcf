"""Extract published benchmark cells from preserved PR JSON snapshots only."""
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parent
NUMBER = r"[+-]?[0-9][0-9,]*(?:\.[0-9]+)?"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load_sources():
    sources = {}
    for number in (1519, 1002):
        path = ROOT / "sources" / f"pr{number}.json"
        raw = path.read_bytes()
        data = json.loads(raw)
        sources[number] = {"pr": number, "url": data["url"], "updated_at": data["updatedAt"],
                           "pr_head": data["headRefOid"], "snapshot": str(path.relative_to(ROOT)),
                           "snapshot_sha256": hashlib.sha256(raw).hexdigest(), "body": data["body"]}
    return sources


def cells(line):
    require(line.startswith("|") and line.endswith("|"), "Unsupported table syntax")
    return [cell.strip() for cell in line[1:-1].split("|")]


def tables(source):
    result, section, section_path, index = [], "", [], 0
    lines = source["body"].splitlines()
    while index < len(lines):
        line = lines[index]
        heading = re.match(r"^(#{1,6}) (.+)$", line)
        if heading:
            level = len(heading[1])
            section = heading[2]
            section_path = [(depth, name) for depth, name in section_path if depth < level] + [(level, section)]
        if line.startswith("|") and index + 1 < len(lines) and re.fullmatch(r"[| :\-]+", lines[index + 1]):
            headers = cells(line)
            table = {"id": f"pr{source['pr']}-table-{len(result) + 1:02d}", "pr": source["pr"], "source_url": source["url"],
                     "section": section, "section_path": [name for _, name in section_path], "header_line": index + 1,
                     "headers": headers, "raw_header": line, "raw_separator": lines[index + 1], "rows": []}
            index += 2
            while index < len(lines) and lines[index].startswith("|"):
                values = cells(lines[index])
                require(len(values) == len(headers), f"Column count mismatch: {table['id']}:{index + 1}")
                table["rows"].append({"body_line": index + 1, "cells": values, "raw_line": lines[index]})
                index += 1
            result.append(table)
            continue
        index += 1
    return result


def numeric(text):
    value = Decimal(text.replace(",", ""))
    return int(value) if value == value.to_integral() else float(value)


def metric(text, unit, provenance, source_cell=None, factor=1, repeats=1, published_unit=None):
    plain = text.strip().removesuffix("%")
    match = re.fullmatch(f"({NUMBER})(?:-({NUMBER}))?", plain)
    require(match is not None, f"Unparsed numeric cell: {text}")
    low, high = match[1], match[2] or match[1]
    lower, upper = Decimal(low.replace(",", "")), Decimal(high.replace(",", ""))
    require(lower <= upper, f"Reversed interval: {text}")
    converted = [value * Decimal(str(factor)) for value in (lower, upper)]
    count_units = {"requests", "retries", "observations", "tokens", "evictions"}
    return {"min": numeric(str(converted[0])), "max": numeric(str(converted[1])),
            "value": numeric(str(converted[0])) if match[2] is None else None,
            "unit": unit, "published_unit": published_unit or unit, "conversion_factor": factor,
            "published": text, "source_cell": source_cell if source_cell is not None else text,
            "published_decimal_places": [len(value.partition(".")[2]) for value in (low, high)],
            "precision": "published integer count" if unit in count_units else "rounded published value; no extra precision recovered",
            "kind": "observed_repeat_range" if repeats > 1 else "published_value",
            "is_confidence_interval": False, "provenance": provenance}


def provenance(table, row, header):
    return {"pr": table["pr"], "source_url": table["source_url"], "section": table["section"],
            "table_id": table["id"], "body_line": row["body_line"], "column": header}


DIRECT = {
    "Successful RPS": ("successful_rps", "requests/s", 1),
    "Admitted RPS": ("admitted_rps", "requests/s", 1),
    "Successful completion RPS": ("successful_completion_rps", "requests/s", 1),
    "Retries": ("retries", "retries", 1), "Client retries": ("retries", "retries", 1),
    "Retries per arm": ("retries", "retries", 1), "Failures per arm": ("failures", "requests", 1),
    "HTTP 429 failures": ("http_429_failures", "requests", 1),
    "Cache hits (%)": ("cache_hit_percent", "% of KV observations", 1),
    "Token reuse (%)": ("reused_input_percent", "% of logical input tokens", 1),
    "Reused input": ("reused_input_percent", "% of logical input tokens", 1),
    "TTFT p99 (ms)": ("ttft_p99_ms", "ms", 1), "TTFT p99 ms": ("ttft_p99_ms", "ms", 1),
    "End-to-end p99 (ms)": ("e2e_p99_ms", "ms", 1), "End-to-end p99 ms": ("e2e_p99_ms", "ms", 1),
    "TTFT p99 (s)": ("ttft_p99_ms", "ms", 1000), "End-to-end p99 (s)": ("e2e_p99_ms", "ms", 1000),
    "Reported reused input tokens/s": ("reported_reused_input_tokens_per_second", "tokens/s", 1),
    "Cache evictions per arm": ("cache_evictions", "evictions", 1),
    "Previous WaW successful RPS": ("previous_successful_rps", "requests/s", 1),
    "New WaW successful RPS": ("new_successful_rps", "requests/s", 1),
    "Previous token reuse (%)": ("previous_reused_input_percent", "% of logical input tokens", 1),
    "New token reuse (%)": ("new_reused_input_percent", "% of logical input tokens", 1),
    "Previous global-path selections (%)": ("previous_global_path_percent", "% of used upstream attempts", 1),
    "New global-path selections (%)": ("new_global_path_percent", "% of used upstream attempts", 1),
    "Previous evictions": ("previous_cache_evictions", "evictions", 1),
    "New evictions": ("new_cache_evictions", "evictions", 1),
    "New reused input tokens/s": ("new_reported_reused_input_tokens_per_second", "tokens/s", 1),
    "Successful RPS change": ("successful_rps_change_percent", "% change", 1),
    "TTFT p99 change": ("ttft_p99_change_percent", "% change", 1),
    "End-to-end p99 change": ("e2e_p99_change_percent", "% change", 1),
}


def normalized_rows(table, repeats):
    result = []
    for source_row in table["rows"]:
        dimensions, metrics = {}, {}
        for header, text in zip(table["headers"], source_row["cells"], strict=True):
            origin = provenance(table, source_row, header)
            def add(name, value, unit, factor=1, published_unit=None):
                metrics[name] = metric(value, unit, origin, text, factor, repeats, published_unit)
            if header in {"Algorithm", "Whole arm"}:
                dimensions["algorithm"] = text
            elif header == "Mode":
                dimensions.update(algorithm="Pulsar-WaW", mode=text.lower())
            elif header in {"Workload", "Matched comparison"}:
                dimensions["workload"] = text
            elif header in {"RPS cap", "Workers", "Step"}:
                dimensions[{"RPS cap": "rate_cap_rps", "Workers": "workers", "Step": "step"}[header]] = numeric(text)
            elif header == "Step / cap":
                step, cap = text.split("/")
                dimensions.update(step=numeric(step.strip()), rate_cap_rps=numeric(cap.strip()))
            elif header in DIRECT:
                name, unit, factor = DIRECT[header]
                add(name, text, unit, factor, "s" if factor == 1000 else unit)
            elif header in {"Failures / requests", "Recorded failures / requests", "Successful / admitted", "Successful/admitted"}:
                first, second = (part.strip() for part in text.split("/"))
                if header in {"Failures / requests", "Recorded failures / requests"}:
                    add("failures", first, "requests"); add("recorded_requests", second, "requests")
                else:
                    add("successful_requests", first, "requests"); add("admitted_requests", second, "requests")
            elif header in {"Cache hits / observations", "Cache hits/observations", "Request cache hits"}:
                match = re.fullmatch(f"({NUMBER})/({NUMBER})(?: \\(({NUMBER})%\\))?", text)
                require(match is not None, f"Unparsed cache cell: {text}")
                add("cache_hits", match[1], "observations"); add("cache_observations", match[2], "observations")
                if match[3] is not None:
                    add("cache_hit_percent", match[3] + "%", "% of KV observations")
            elif header == "Failures":
                match = re.fullmatch(f"({NUMBER})(?: \\((\\d+): ({NUMBER})\\))?", text)
                require(match is not None, f"Unparsed failure cell: {text}")
                add("failures", match[1], "requests")
                if match[2] is not None:
                    add(f"http_{match[2]}_failures", match[3], "requests")
            elif header in {"Mean", "Maximum"}:
                add(header.lower() + "_reused_input_percent", text, "% of logical input tokens")
            else:
                raise ValueError(f"Unmapped header: {header}")
        if table["section"] == "Pulsar-WaW ramp follow-up" and "Step / cap" in table["headers"]:
            dimensions["algorithm"] = "Pulsar-WaW"
        result.append({"dimensions": dimensions, "metrics": metrics,
                       "provenance": provenance(table, source_row, None), "published_cells": dict(zip(table["headers"], source_row["cells"], strict=True))})
    return result


CONFIG = [
    ("five_region_reduced", "Five-region benchmark results", 0, "reduced", 1),
    ("five_region_cold_capacity", "Five-region benchmark results", 1, "cold_capacity", 1),
    ("growing_kv_affine2_wait200", "High-load KV session benchmark results", 0, "growing_old", 2),
    ("growing_kv_affine2_wait200_cache", "High-load KV session benchmark results", 1, "growing_old", 2),
    ("growing_kv_affine1_wait300", "KV session candidate: one affine backend, 300 ms", 0, "growing_new", 2),
    ("growing_kv_historical_comparison", "KV session candidate: one affine backend, 300 ms", 1, "growing_comparison", 2),
    ("growing_kv_placement_comparison", "KV session candidate: one affine backend, 300 ms", 2, "growing_comparison", 2),
    ("ramp_original_steps", "Continuous cache-preserving ramp results", 0, "ramp_original", 1),
    ("ramp_original_totals", "Continuous cache-preserving ramp results", 1, "ramp_original", 1),
    ("ramp_historical_totals", "Pulsar-WaW ramp follow-up", 0, "ramp_legacy_pulsar", 1),
    ("ramp_legacy_pulsar_steps", "Pulsar-WaW ramp follow-up", 1, "ramp_legacy_pulsar", 1),
    ("ramp_same_build_totals", "Same-build routing validation", 0, "ramp_new_pulsar", 1),
    ("ramp_same_build_final120s", "Same-build routing validation", 1, "ramp_new_pulsar", 1),
    ("historical_two_region_reduced", "Historical two-region benchmark results", 0, "two_region", 1),
    ("historical_two_region_changes", "Historical two-region benchmark results", 1, "two_region", 1),
]


def metadata(kind, repeats, old_build, new_build):
    ramp = kind.startswith("ramp_")
    growing = kind.startswith("growing_")
    two_region = kind == "two_region"
    value = {
        "topology": {"regions": 2 if two_region else 5, "backends": 8 if two_region else 20,
                     "ingress": "us-west-2", "engine_concurrency_per_backend": 25},
        "application_build": new_build if kind == "ramp_new_pulsar" else old_build,
        "repeats_per_algorithm_per_condition": repeats,
        "range_meaning": "observed min/max across two repeats; published equal endpoints may be printed once" if repeats == 2 else "single published observation; not a repeatability range",
        "is_confidence_interval": False, "precision": "published rounded numbers only; exact printed cells retained",
        "latency_definition": "published rounding of exact nearest-rank successful-request p99 including client retries" if ramp else "published histogram bucket lower-bound successful-request p99 including client retries",
        "throughput_definition": "successful requests divided by whole-run wall duration including final drain" if ramp or growing else "completed successful requests divided by measured run duration; fixed-duration reports exclude window-end in-flight cancellations",
        "cache_definition": "cache-hit percent uses response KV observations; token reuse uses all admitted logical input tokens including failures" if ramp or growing else "cache-hit percentages use reported KV observations; not token-reuse percentages",
        "statistics": "fallback estimators; engine stats stream disabled; startup calibration maximum 25; periodic canaries disabled",
        "production_recommendation": "pending real-engine QA",
    }
    if growing:
        value.update(workload={"sessions": 768, "workers": 768, "turns_per_session": 16, "requests_per_arm": 12288,
                               "input_tokens_range": [6181, 6661], "logical_input_tokens_per_arm": 78901248,
                               "output_token_cap": 256, "slo_ms": 10000, "maximum_wait_ms": 10000, "timeout_s": 30,
                               "prompt_pattern": "sequential growing turns; cold reset before each fixed-count arm; no prewarming"},
                     paired_design="Two matched WaW/PowerOf2 pairs per cap; second pair reverses algorithm order.")
        if kind == "growing_old":
            value["waw_policy"] = {"affine_backends": 2, "affinity_wait_ms": 200, "max_queued": 4}
        elif kind == "growing_new":
            value["waw_policy"] = {"affine_backends": 1, "affinity_wait_ms": 300, "max_queued": 4}
        else:
            value["paired_design"] = "Historical comparison of two different dates; each candidate has its own contemporaneous PowerOf2 controls. These rows add no new runs."
    elif ramp:
        value.update(workload={"sessions": 768, "workers": 768, "input_tokens": 6661, "output_token_cap": 256,
                               "rate_caps_rps": [160, 180, 200, 180, 160], "step_duration_s": 180,
                               "slo_ms": 10000, "maximum_wait_ms": 10000, "timeout_s": 30,
                               "prompt_pattern": "fixed repeated prompt per session; cold reset before arm, caches and in-flight work preserved across steps"},
                     phase_definition="Failures, retries, cache values and latency use admission cohorts; completion RPS counts completions in the time window and includes carryover.")
        if kind == "ramp_original":
            value.update(paired_design="One matched WaW/PowerOf2 pair; phase rows reuse the same two arms.",
                         waw_policy={"affine_backends": 1, "affinity_wait_ms": 300, "max_queued": 4})
        else:
            value["pulsar_policy"] = {"queue_floor_ms": 4000, "queue_ceiling_ms": 4000, "max_queued": 4,
                                      "n": 2, "ttft_bucket_ms": 20, "unlock_factor": 0.25, "consider_kv_free_tokens": False}
            value["paired_design"] = "One same-build mean-then-maximum pair; legacy mean explicitly selected, maximum default tested. Historical PowerOf2 is not a fresh control." if kind == "ramp_new_pulsar" else "One fresh mean-based Pulsar-WaW arm reuses the preceding WaW/PowerOf2 controls; not a new three-way matched pair."
    elif kind == "cold_capacity":
        value.update(paired_design="One matched pair per configured cap; algorithm order alternates across caps.",
                     workload={"duration_s": 120, "output_token_cap": 256, "slo_ms": 10000, "maximum_wait_ms": 10000, "timeout_s": 30,
                               "prompt_pattern": "disjoint cold prompts; cache and estimator state carried between arms"},
                     cache_definition="All cold-capacity reports explicitly record zero cache hits.")
    else:
        value["paired_design"] = "One matched session pair, one concurrent mixed hot/short pair, and one capacity pair; hot/short reports share the mixed arms."
    return value


def prose_rows(source, pattern, section, algorithm, metric_name, unit):
    found = [(i, line, re.search(pattern, line)) for i, line in enumerate(source["body"].splitlines(), 1) if re.search(pattern, line)]
    require(len(found) == 1, f"Expected one prose match: {pattern}")
    line_number, line, match = found[0]
    values = re.findall(r"([0-9]+\.[0-9]+)%", match[1])
    require(len(values) == 5, f"Expected five published phase values: {pattern}")
    rows = []
    for step, (rate, value) in enumerate(zip((160, 180, 200, 180, 160), values, strict=True), 1):
        origin = {"pr": source["pr"], "source_url": source["url"], "section": section, "table_id": None,
                  "body_line": line_number, "column": None}
        rows.append({"dimensions": {"algorithm": algorithm, "step": step, "rate_cap_rps": rate},
                     "metrics": {metric_name: metric(value + "%", unit, origin, line)},
                     "provenance": origin, "published_cells": {"paragraph": line}})
    return rows


def main():
    sources = load_sources()
    all_tables = [table for source in sources.values() for table in tables(source)]
    old_build = re.search(r"Earlier WaW/PowerOf2 results used application commit `([^`]+)`", sources[1519]["body"])[1]
    new_build = re.search(r"Pylon images from `([^`]+)`", sources[1002]["body"])[1]
    datasets = []
    for identifier, section, ordinal, kind, repeats in CONFIG:
        matches = [t for t in all_tables if t["section"] == section]
        table = matches[ordinal]
        dataset = {"id": identifier, "section": section, "source_pr": table["pr"], "table_ids": [table["id"]],
                   **metadata(kind, repeats, old_build, new_build), "rows": normalized_rows(table, repeats)}
        if identifier == "ramp_same_build_final120s":
            dataset["window"] = "last 120 seconds of each 180-second step"
        datasets.append(dataset)
    old_reuse = []
    for pattern, section, algorithm in [
        (r"WaW reuse is (.+?)\. Corresponding", "Continuous cache-preserving ramp results", "WaW"),
        (r"Corresponding PowerOf2 reuse is (.+?)\. The transition", "Continuous cache-preserving ramp results", "PowerOf2"),
        (r"Pulsar-WaW reuse is (.+?); ordinary", "Pulsar-WaW ramp follow-up", "Pulsar-WaW"),
    ]:
        old_reuse.extend(prose_rows(sources[1519], pattern, section, algorithm, "reused_input_percent", "% of logical input tokens"))
    datasets.append({"id": "ramp_old_final120s", "section": "Published final-120s reuse prose", "source_pr": 1519,
                     "table_ids": [], **metadata("ramp_legacy_pulsar", 1, old_build, new_build),
                     "window": "last 120 seconds of each 180-second step", "rows": old_reuse})
    routing = prose_rows(sources[1519], r"Approximate WaW global-path shares across the five steps are (.+?)\. These", "Continuous cache-preserving ramp results", "WaW", "global_path_percent", "% of used upstream attempts")
    routing += prose_rows(sources[1519], r"Approximate Pulsar-WaW fallback shares are (.+?)\. For this", "Pulsar-WaW ramp follow-up", "Pulsar-WaW", "rank_beyond_one_percent", "% of used upstream attempts")
    datasets.append({"id": "ramp_old_routing_diagnostics", "section": "Published approximate routing shares", "source_pr": 1519,
                     "table_ids": [], **metadata("ramp_legacy_pulsar", 1, old_build, new_build),
                     "limitations": "WaW global-path and Pulsar rank-beyond-one shares are different metrics. Both count upstream attempts including internal retries; neither gives exact off-affinity logical-request destinations. Scrape alignment is approximate.", "rows": routing})
    checks = selfcheck(sources, all_tables, datasets)
    document = {"schema_version": 1, "source_scope": "Preserved PR JSON bodies only; original raw benchmark artifacts were deleted.",
                "raw_artifacts_available": False,
                "limitations": ["All numbers are transcribed at published precision; raw timelines, original reports and checksums cannot be revalidated.",
                                "Source statements that reports passed checks describe prior validation, not newly repeated evidence verification.",
                                "Two-repeat ranges are observed extrema, not confidence intervals. Single-pair values do not establish repeatability.",
                                "No raw time-series samples, uncertainty estimates, or unreported per-repeat values are reconstructed.",
                                "Application revisions, topology and prompt patterns differ between experiment groups; comparisons must preserve those scopes.",
                                "Production recommendation remains pending real-engine QA."],
                "sources": [{key: value for key, value in source.items() if key != "body"} for source in sources.values()],
                "raw_tables": all_tables, "datasets": datasets, "selfcheck": checks}
    (ROOT / "results.json").write_text(json.dumps(document, indent=2, allow_nan=False) + "\n")
    csv_rows = []
    for dataset in datasets:
        for row in dataset["rows"]:
            for name, value in row["metrics"].items():
                csv_rows.append({"dataset": dataset["id"], "regions": dataset["topology"]["regions"], "backends": dataset["topology"]["backends"],
                                 "application_build": dataset["application_build"], "repeats": dataset["repeats_per_algorithm_per_condition"],
                                 **{key: row["dimensions"].get(key) for key in ("algorithm", "mode", "workload", "rate_cap_rps", "workers", "step")},
                                 "metric": name, **{key: value[key] for key in ("value", "min", "max", "unit", "published_unit", "conversion_factor", "published", "source_cell", "precision", "kind")},
                                 **{key: value["provenance"][key] for key in ("pr", "section", "table_id", "body_line", "column")}})
    with (ROOT / "results.csv").open("w", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=list(csv_rows[0]))
        writer.writeheader(); writer.writerows(csv_rows)
    print(json.dumps({"tables": len(all_tables), "datasets": len(datasets), "normalized_rows": sum(len(d["rows"]) for d in datasets),
                      "metric_cells": len(csv_rows), "checks": checks}, indent=2))


def selfcheck(sources, raw_tables, datasets):
    table_map = {t["id"]: t for t in raw_tables}
    checked = 0
    for table in raw_tables:
        lines = sources[table["pr"]]["body"].splitlines()
        require(lines[table["header_line"] - 1] == table["raw_header"], "Header provenance mismatch")
        for row in table["rows"]:
            require(lines[row["body_line"] - 1] == row["raw_line"], "Raw row provenance mismatch")
            require(cells(row["raw_line"]) == row["cells"], "Cell transcription mismatch")
            checked += len(row["cells"])
    for dataset in datasets:
        for row in dataset["rows"]:
            for value in row["metrics"].values():
                origin = value["provenance"]
                if origin["table_id"]:
                    table = table_map[origin["table_id"]]
                    source_row = next(r for r in table["rows"] if r["body_line"] == origin["body_line"])
                    cell = source_row["cells"][table["headers"].index(origin["column"])]
                else:
                    cell = sources[origin["pr"]]["body"].splitlines()[origin["body_line"] - 1]
                require(cell == value["source_cell"], "Metric cell provenance mismatch")
                require(value["published"].removesuffix("%") in cell, "Metric extraction not present in published cell")
    new1519 = [t for t in raw_tables if t["section"] == "Pulsar-WaW maximum-TPS validation"]
    new1002 = [t for t in raw_tables if t["section"] == "Same-build routing validation"]
    require(len(new1519) == len(new1002) == 2, "Missing corroborating maximum-TPS tables")
    for left, right in zip(new1519, new1002, strict=True):
        require(left["headers"] == right["headers"] and [r["cells"] for r in left["rows"]] == [r["cells"] for r in right["rows"]], "Published PR maximum-TPS tables disagree")
    lookup = {d["id"]: d for d in datasets}
    comparisons = lookup["growing_kv_historical_comparison"]["rows"]
    for row in comparisons:
        rate = row["dimensions"]["rate_cap_rps"]
        for prefix, identifier in (("previous", "growing_kv_affine2_wait200"), ("new", "growing_kv_affine1_wait300")):
            source_row = next(r for r in lookup[identifier]["rows"] if r["dimensions"] == {"rate_cap_rps": rate, "algorithm": "WaW"})
            for name in ("successful_rps", "reused_input_percent"):
                require(row["metrics"][prefix + "_" + name]["published"] == source_row["metrics"][name]["published"], "Candidate comparison differs from original published ranges")
    for row in lookup["ramp_original_totals"]["rows"]:
        repeated = next(r for r in lookup["ramp_historical_totals"]["rows"] if r["dimensions"] == row["dimensions"])
        for name, value in row["metrics"].items():
            comparison_name = "http_429_failures" if name == "failures" else name
            require(value["published"] == repeated["metrics"][comparison_name]["published"], "Reused historical controls differ between tables")
    for dataset in datasets:
        for row in dataset["rows"]:
            values = {name: value["value"] for name, value in row["metrics"].items()}
            if {"successful_requests", "admitted_requests", "failures"} <= values.keys():
                require(values["successful_requests"] + values["failures"] == values["admitted_requests"], "Outcome counts disagree")
            if {"cache_hits", "cache_observations"} <= values.keys():
                require(0 <= values["cache_hits"] <= values["cache_observations"], "Cache counts disagree")
            if "ttft_p99_ms" in row["metrics"]:
                require(row["metrics"]["ttft_p99_ms"]["max"] <= row["metrics"]["e2e_p99_ms"]["max"], "Latency units or ordering disagree")
    return {"raw_table_cells_exactly_rechecked": checked, "metric_provenance_rechecked": True,
            "new_mean_max_tables_agree_between_prs": True, "growing_candidate_comparison_ranges_agree": True,
            "reused_historical_controls_agree": True, "outcome_and_cache_counts_consistent": True,
            "measurement_evidence_revalidated": False}


if __name__ == "__main__":
    main()
