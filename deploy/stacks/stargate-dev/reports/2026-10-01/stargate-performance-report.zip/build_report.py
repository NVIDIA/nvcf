"""Render the preserved benchmark summaries as a self-contained report."""
from __future__ import annotations

import base64
import csv
import hashlib
import html
import json
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FuncFormatter

ROOT = Path(__file__).resolve().parent
CHARTS = ROOT / "graphs"
CHARTS.mkdir(exist_ok=True)
INK = "#192e43"
MUTED = "#536575"
BLUE = "#2864ba"
GREEN = "#087d68"
ORANGE = "#bc620c"
PURPLE = "#7851a9"
RED = "#ba3f3c"
COLORS = {"WaW": GREEN, "PowerOf2": BLUE, "Pulsar-WaW": ORANGE,
          "Mean": ORANGE, "Maximum": PURPLE}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
    "axes.labelcolor": INK, "text.color": INK, "xtick.color": MUTED,
    "ytick.color": MUTED, "axes.titleweight": "bold", "axes.titlesize": 10,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#b8c4ce", "grid.color": "#e4e9ef",
    "grid.linewidth": .65, "svg.fonttype": "none", "savefig.facecolor": "white"})


def clean_axis(ax, title, ylabel=None):
    ax.set_title(title, loc="left", pad=11)
    if ylabel:
        ax.set_ylabel(ylabel)
    ax.set_axisbelow(True)
    ax.grid(axis="y")
    ax.tick_params(labelsize=8)


def save_figure(fig, name):
    for extension in ("svg", "png"):
        fig.savefig(CHARTS / f"{name}.{extension}", dpi=190, bbox_inches="tight", pad_inches=.13)
    plt.close(fig)
    return name


def figure(name, caption, height=None):
    path = CHARTS / (name + ".svg")
    encoded = base64.b64encode(path.read_bytes()).decode()
    style = f' style="height:{height}mm"' if height else ""
    return f'<figure><img alt="{html.escape(caption)}" src="data:image/svg+xml;base64,{encoded}"{style}><figcaption>{caption}</figcaption></figure>'


def table(headers, rows, cls=""):
    return '<table class="' + cls + '"><thead><tr>' + ''.join('<th>' + html.escape(str(x)) + '</th>' for x in headers) + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join('<td>' + html.escape(str(x)) + '</td>' for x in row) + '</tr>' for row in rows) + '</tbody></table>'


def para(text, cls=""):
    return f'<p class="{cls}">{text}</p>'


def bullets(items):
    return '<ul>' + ''.join('<li>' + x + '</li>' for x in items) + '</ul>'


PAGES = []


def page(kicker, title, body):
    PAGES.append(f'<section class="page"><header><span>STARGATE / ROUTING PERFORMANCE</span><span>01 OCT 2026</span></header><div class="kicker">{kicker}</div><h1>{title}</h1><main>{body}</main><footer><span>Five-region development benchmarks | Published-summary reconstruction</span><span>{len(PAGES)+1:02d}</span></footer></section>')


STYLE = """
* {box-sizing:border-box} body {margin:0;background:#e8edf2;color:#192e43;font:12px/1.48 Arial,Helvetica,sans-serif}
.page {width:210mm;height:297mm;padding:12mm;margin:18px auto;background:white;position:relative;box-shadow:0 3px 15px #22334422}
header {display:flex;justify-content:space-between;font-size:8px;letter-spacing:1.1px;border-bottom:1px solid #ccd7e1;padding-bottom:8px;color:#536575}
.kicker {font-size:9px;letter-spacing:1.2px;text-transform:uppercase;color:#087d68;margin-top:15px;font-weight:700}
h1 {font-size:25px;line-height:1.13;margin:5px 0 13px;letter-spacing:-.5px} h2 {font-size:15px;margin:16px 0 5px} h3 {font-size:12px;margin:13px 0 4px}
p {margin:7px 0 10px} .lead {font-size:14px;line-height:1.45} .small,figcaption {font-size:10px;line-height:1.4;color:#536575}
.note {border-left:3px solid #bb650c;background:#fff6e9;padding:10px 12px;font-size:11px}.finding {border-left:3px solid #087d68;padding:8px 12px;background:#edf7f4}
table {border-collapse:collapse;width:100%;font-size:10px;margin:10px 0 13px} th {background:#edf2f6;text-align:left;color:#192e43;padding:7px 6px;border-bottom:1px solid #bac8d4} td {padding:6px;border-bottom:1px solid #e1e7ec;vertical-align:top} tbody tr:nth-child(even) {background:#f8fafc}
table.compact {font-size:9px} table.compact td,table.compact th {padding:5px 4px}
figure {margin:9px 0 12px} figure img {width:100%;display:block;object-fit:contain} figcaption {margin-top:5px}
ul {padding-left:18px;margin:8px 0 12px} li {margin:6px 0} code {font:10px Consolas,monospace;background:#f0f3f6;padding:1px 3px}
a {color:#235e9d} .cols {display:grid;grid-template-columns:1fr 1fr;gap:18px}.cols p {margin-top:5px}
footer {position:absolute;bottom:9mm;left:12mm;right:12mm;display:flex;justify-content:space-between;font-size:8px;color:#697a89;border-top:1px solid #d3dde5;padding-top:7px}
@page {size:A4 portrait;margin:12mm}
@media print {body {background:white}.page {width:186mm;height:273mm;padding:0;margin:0;box-shadow:none;break-after:page}.page:last-child {break-after:auto}footer {bottom:0;left:0;right:0}a {text-decoration:none}}
"""

DATA = json.loads((ROOT / "results.json").read_text())
DS = {d["id"]: d for d in DATA["datasets"]}
assert DATA["raw_artifacts_available"] is False


def rows(dataset, **filters):
    return [r for r in DS[dataset]["rows"] if all(r["dimensions"].get(k) == v for k, v in filters.items())]


def one(dataset, **filters):
    selected = rows(dataset, **filters)
    assert len(selected) == 1, (dataset, filters, len(selected))
    return selected[0]


def val(row, metric):
    value = row["metrics"][metric]["value"]
    assert value is not None, "A range must not be plotted as an invented average"
    return value


def fmt(row, metric, digits=2, scale=1):
    m = row["metrics"][metric]
    if m["value"] is not None:
        return f'{m["value"]/scale:,.{digits}f}'
    return f'{m["min"]/scale:,.{digits}f}-{m["max"]/scale:,.{digits}f}'


MEAN = one("ramp_same_build_totals", mode="mean")
MAX = one("ramp_same_build_totals", mode="maximum")
STEP_LABELS = ["1: 160\nopening", "2: 180\nupward", "3: 200\npeak", "4: 180\nreturn", "5: 160\nrecovery"]


def cache_comparison():
    fig, ax = plt.subplots(figsize=(7.15, 2.85))
    x = np.arange(5)
    r = rows("ramp_same_build_final120s")
    for shift, mode, color in [(-.18, "mean", ORANGE), (.18, "maximum", PURPLE)]:
        values = [val(v, mode + "_reused_input_percent") for v in r]
        bars = ax.bar(x + shift, values, .34, color=color, label=mode.capitalize())
        ax.bar_label(bars, labels=[f"{v:.1f}%" for v in values], fontsize=8, padding=3)
    ax.set_xticks(x, STEP_LABELS)
    ax.set_ylim(0, 107)
    clean_axis(ax, "Cache reuse survives the upward 180 RPS step", "Reused input (%)")
    ax.legend(frameon=False, ncol=2, loc="upper center", bbox_to_anchor=(.62, 1.0), fontsize=8)
    fig.tight_layout()
    fig.text(.02, -.025, "Build B: 8a981aeadd31. Last 120 s of each 180 s step; one matched mean/maximum pair.\nPublished step summaries, not a reconstructed request timeline.", fontsize=8, color=MUTED)
    return save_figure(fig, "01-maximum-cache-reuse")


def scorecard():
    series = [("PowerOf2 [A]", one("ramp_historical_totals", algorithm="PowerOf2"), BLUE),
              ("WaW [A]", one("ramp_historical_totals", algorithm="WaW"), GREEN),
              ("Pulsar mean [A]", one("ramp_historical_totals", algorithm="Pulsar-WaW"), ORANGE),
              ("Pulsar mean [B]", MEAN, ORANGE), ("Pulsar maximum [B]", MAX, PURPLE)]
    fig, axes = plt.subplots(3, 2, figsize=(7.3, 7.1))
    positions = [5, 4, 3, 1, 0]
    specs = [("successful_rps", "Successful throughput", "Requests/s; higher is better", 1, 2),
             ("reused_input_percent", "Input-token reuse", "Percent; higher is better", 1, 2),
             ("ttft_p99_ms", "TTFT p99", "Seconds; lower is better", 1000, 2),
             ("e2e_p99_ms", "End-to-end p99", "Seconds; lower is better", 1000, 2),
             ("failures", "Terminal failures", "Count; A: HTTP 429 / B: HTTP 503", 1, 0),
             ("retries", "Client retries", "Count; lower is better", 1, 0)]
    for ax, (key, title, unit, scale, digits) in zip(axes.flat, specs):
        values = [val(r, "http_429_failures" if key == "failures" and "failures" not in r["metrics"] else key) / scale for _, r, _ in series]
        ax.axhspan(-.5, 1.5, color="#f0edf8", zorder=0)
        bars = ax.barh(positions, values, .64, color=[c for _, _, c in series])
        ax.bar_label(bars, labels=[f"{v:,.{digits}f}" for v in values], padding=3, fontsize=8)
        ax.set_yticks(positions, [name for name, _, _ in series], fontsize=7.5)
        ax.set_xlim(0, max(values) * 1.29 if key != "reused_input_percent" else 100)
        ax.set_ylim(-.7, 5.7)
        ax.set_title(title, loc="left", pad=10)
        ax.set_xlabel(unit, fontsize=8)
        ax.grid(axis="x")
        ax.set_axisbelow(True)
        ax.tick_params(axis="x", labelsize=7)
        ax.xaxis.set_major_locator(plt.MaxNLocator(4))
    fig.tight_layout(h_pad=2.7, w_pad=1.7)
    fig.text(.02, -.018, "A: original build 1309d5d642dd. B: maximum-TPS build 8a981aeadd31.\nCompare within build groups; values across groups are historical context. One arm per row.", fontsize=8, color=MUTED)
    return save_figure(fig, "02-ramp-scorecard")


def workload_changes(dataset, name):
    workloads = list(dict.fromkeys(r["dimensions"]["workload"] for r in rows(dataset)))
    labels = [w.replace("Cold 96 RPS, 192 workers", "Cold 96 RPS\n192 workers").replace("Cold capacity 96 RPS", "Cold 96 RPS") for w in workloads]
    fig, axes = plt.subplots(1, 3, figsize=(7.25, 3.7))
    for ax, key, title in zip(axes, ["successful_rps", "ttft_p99_ms", "e2e_p99_ms"], ["Successful RPS", "TTFT p99", "End-to-end p99"]):
        delta = [(val(one(dataset, workload=w, algorithm="WaW"), key) / val(one(dataset, workload=w, algorithm="PowerOf2"), key) - 1) * 100 for w in workloads]
        colors = [GREEN if (v >= 0 if key == "successful_rps" else v <= 0) else RED for v in delta]
        bars = ax.barh(np.arange(len(workloads)), delta, color=colors, height=.55)
        ax.bar_label(bars, labels=["" if -5 < v < 0 else f"{v:+.1f}%" for v in delta], padding=4, fontsize=8)
        for bar, change in zip(bars, delta):
            if -5 < change < 0:
                ax.annotate(f"{change:+.1f}%", (0, bar.get_y()+bar.get_height()/2), xytext=(4,0), textcoords="offset points", va="center", fontsize=8)
        ax.set_yticks(range(len(workloads)), labels if ax == axes[0] else [])
        ax.invert_yaxis()
        ax.axvline(0, color=MUTED, linewidth=.8)
        ax.set_title(title, loc="left")
        ax.set_xlabel("WaW change vs PowerOf2", fontsize=8)
        lo, hi = min(0, min(delta)), max(0, max(delta))
        extent = max(hi-lo, 5)
        ax.set_xlim(lo - .27*extent, hi + .37*extent)
        ax.xaxis.set_major_locator(plt.MaxNLocator(4))
        ax.grid(axis="x"); ax.set_axisbelow(True)
        ax.tick_params(labelsize=8)
    fig.tight_layout(w_pad=1.7)
    topology = DS[dataset]["topology"]
    fig.text(.02, -.025, f"{topology['regions']} regions / {topology['backends']} backends. One matched pair per workload. Green: favorable; red: unfavorable.\nDerived from published rounded values; p99 is a histogram bucket lower bound.", fontsize=8, color=MUTED)
    return save_figure(fig, name)


def cold_capacity():
    fig, axes = plt.subplots(2, 2, figsize=(7.15, 5.55))
    specs = [("successful_rps", "Successful throughput", "Requests/s", 1),
             ("ttft_p99_ms", "TTFT p99", "Seconds", 1000),
             ("e2e_p99_ms", "End-to-end p99", "Seconds", 1000),
             ("retries", "Retries per 1,000 recorded requests", "Retries / 1,000", None)]
    for ax, (metric, title, unit, scale) in zip(axes.flat, specs):
        for algo, marker in [("PowerOf2", "o"), ("WaW", "s")]:
            selected = rows("five_region_cold_capacity", algorithm=algo)
            rates = [r["dimensions"]["rate_cap_rps"] for r in selected]
            values = [val(r, metric)/scale if scale else val(r, metric)/val(r, "recorded_requests")*1000 for r in selected]
            ax.plot(rates, values, marker=marker, color=COLORS[algo], label=algo, linewidth=1.6, markersize=5)
        clean_axis(ax, title, unit)
        ax.set_xticks(rates)
        ax.set_xlabel("Configured RPS cap", fontsize=8)
        ax.set_ylim(bottom=0)
    axes[0, 0].legend(frameon=False, fontsize=8)
    fig.tight_layout(h_pad=2.2, w_pad=1.6)
    fig.text(.02, -.018, "Workers by cap: 96/768, 160/768, 200/800, 240/960, 320/1280. One matched pair per cap.\nBuild 1309d5d642dd; 20 backends; zero cache hits; histogram bucket lower-bound p99.", fontsize=8, color=MUTED)
    return save_figure(fig, "04-cold-capacity")


def growing_ranges():
    fig, axes = plt.subplots(3, 2, figsize=(7.15, 7.25))
    configs = [("growing_kv_affine2_wait200", "2 affine backends / 200 ms"), ("growing_kv_affine1_wait300", "1 affine backend / 300 ms")]
    specs = [("reused_input_percent", "Input-token reuse (%)", 1, (0, 100)),
             ("successful_rps", "Successful requests/s", 1, (140, 166)),
             ("ttft_p99_ms", "TTFT p99 (seconds)", 1000, (0, 8))]
    for col, (dataset, label) in enumerate(configs):
        for row_index, (metric, unit, scale, limits) in enumerate(specs):
            ax = axes[row_index, col]
            for algo, offset in [("PowerOf2", -.12), ("WaW", .12)]:
                selected = rows(dataset, algorithm=algo)
                x = np.arange(4) + offset
                low = [r["metrics"][metric]["min"]/scale for r in selected]
                high = [r["metrics"][metric]["max"]/scale for r in selected]
                ax.vlines(x, low, high, color=COLORS[algo], linewidth=3, label=algo)
                ax.scatter(x, low, color=COLORS[algo], marker="_", s=65)
                ax.scatter(x, high, color=COLORS[algo], marker="_", s=65)
            clean_axis(ax, label if row_index == 0 else "", unit)
            ax.set_xticks(range(4), [160, 200, 240, 320])
            ax.set_xlim(-.5, 3.5); ax.set_ylim(limits)
            if row_index == 2: ax.set_xlabel("Configured RPS cap", fontsize=8)
            if row_index == 0: ax.legend(frameon=False, fontsize=8)
    fig.tight_layout(h_pad=2.0, w_pad=2.0)
    fig.text(.02, -.018, "Vertical spans: observed min/max of two repeats, not confidence intervals or averages.\nSeparate campaigns with their own matched PowerOf2 controls. Throughput axis starts at 140.", fontsize=8, color=MUTED)
    return save_figure(fig, "05-growing-session-ranges")


def original_ramp():
    fig, axes = plt.subplots(2, 2, figsize=(7.15, 5.8))
    specs = [("reused_input_percent", "Cache reuse: last 120 s of each step", "Percent", 1),
             ("successful_completion_rps", "Successful completions: whole step", "Requests/s", 1),
             ("ttft_p99_ms", "TTFT p99: whole-step admission cohort", "Seconds", 1000),
             ("e2e_p99_ms", "End-to-end p99: whole-step cohort", "Seconds", 1000)]
    for ax, (metric, title, unit, scale) in zip(axes.flat, specs):
        for index, algo in enumerate(["PowerOf2", "WaW", "Pulsar-WaW"]):
            if metric == "reused_input_percent": selected = rows("ramp_old_final120s", algorithm=algo)
            else: selected = rows("ramp_legacy_pulsar_steps" if algo == "Pulsar-WaW" else "ramp_original_steps", algorithm=algo)
            values = [val(r, metric)/scale for r in selected]
            ax.bar(np.arange(5)+(index-1)*.24, values, .23, label="Pulsar mean (build A)" if algo == "Pulsar-WaW" else algo, color=COLORS[algo])
        clean_axis(ax, title, unit)
        ax.set_xticks(range(5), ["160\nopen", "180\nup", "200\npeak", "180\nback", "160\nback"], fontsize=8)
        ax.set_ylim(bottom=0)
        if metric == "reused_input_percent": ax.set_ylim(0, 105)
        if metric == "successful_completion_rps":
            ax.plot(range(5), [160,180,200,180,160], marker="_", color=MUTED, linestyle="none", markersize=17, label="Rate cap")
            ax.set_ylim(0, 220)
            ax.legend(handles=[ax.lines[-1]], labels=["Configured RPS cap"], frameon=False, fontsize=7, loc="upper center", bbox_to_anchor=(.5, 1.33))
    axes[0, 0].legend(frameon=False, fontsize=7, ncol=3, loc="upper center", bbox_to_anchor=(.5, 1.35))
    fig.tight_layout(h_pad=2.5, w_pad=1.9)
    fig.text(.02, -.018, "Build A: 1309d5d642dd. Pulsar follow-up reuses the preceding WaW/PowerOf2 controls.\nDiscrete step summaries; no continuous request timeline is reconstructed.", fontsize=8, color=MUTED)
    return save_figure(fig, "06-original-ramp")


def new_pair_risk():
    fig, axes = plt.subplots(1, 2, figsize=(7.1, 2.9))
    for ax, metric, title in zip(axes, ["failures", "retries"], ["Terminal HTTP 503s per 1,000 admissions", "Retries per 1,000 admissions"]):
        values = [val(r, metric)/val(r, "admitted_requests")*1000 for r in (MEAN, MAX)]
        bars = ax.bar(["Mean", "Maximum"], values, color=[ORANGE, PURPLE], width=.52)
        ax.bar_label(bars, labels=[f"{v:.3f}" if metric == "failures" else f"{v:.1f}" for v in values], padding=4)
        clean_axis(ax, title)
        ax.set_ylim(0, max(values)*1.28)
    fig.tight_layout(w_pad=3)
    fig.text(.02, -.025, "Build B: 8a981aeadd31. One matched pair: 146,288 mean / 149,937 maximum admissions.\nAll terminal failures in these two arms are HTTP 503.", fontsize=8, color=MUTED)
    return save_figure(fig, "07-maximum-failures-retries")


def metric_table_pair():
    specs = [("Successful / admitted", "counts", 0, 1), ("Successful requests/s", "successful_rps", 3, 1),
             ("Cache hits / observations", "hits", 0, 1), ("Input-token reuse", "reused_input_percent", 2, 1),
             ("TTFT p99 (s)", "ttft_p99_ms", 2, 1000), ("End-to-end p99 (s)", "e2e_p99_ms", 2, 1000),
             ("Terminal HTTP 503s", "failures", 0, 1), ("Client retries", "retries", 0, 1)]
    out = []
    for label, key, digits, scale in specs:
        if key == "counts": values = [fmt(r, "successful_requests", 0)+" / "+fmt(r, "admitted_requests", 0) for r in (MEAN,MAX)]
        elif key == "hits": values = [fmt(r,"cache_hits",0)+" / "+fmt(r,"cache_observations",0) for r in (MEAN,MAX)]
        else: values = [fmt(r,key,digits,scale)+("%" if key == "reused_input_percent" else "") for r in (MEAN,MAX)]
        out.append([label]+values)
    return table(["Whole 15-minute ramp + drain", "Mean", "Maximum (default)"], out)


def report():
    cache_comparison(); scorecard(); workload_changes("five_region_reduced", "03-workload-changes")
    cold_capacity(); growing_ranges(); original_ramp(); new_pair_risk()
    workload_changes("historical_two_region_reduced", "08-two-region-context")

    page("Final report / Decision summary", "Cache affinity helps until load breaks reuse",
        para("WaW is useful for cache-sensitive traffic below the observed pressure transition. It has not shown a consistent performance advantage over PowerOf2 across the tested workloads.", "lead") +
        para("The maximum-TPS change improves Pulsar-WaW against its same-build mean control: throughput rises 2.45%, TTFT p99 falls 14.86%, and end-to-end p99 falls 12.00%. Failures and retries increase.", "finding") +
        metric_table_pair() +
        figure("01-maximum-cache-reuse", "New-build matched pair: input-token reuse over the last 120 s of each 180 s step. Bars are discrete published summaries, not a recovered request timeline.", 79) +
        para("Maximum weighting moves the observed reuse drop from upward 180 to 200 RPS. Reuse remains low on the return to 180 and recovers at 160. This is one pair, not a repeatability estimate.") +
        para("Evidence basis: reconstructed from preserved PR #1519 and #1002 summaries. The raw artifacts were deleted. Values retain published rounding; original hash checks and request timelines cannot be independently rechecked here. Production recommendation remains pending real-engine QA.", "note"))

    page("Study design / Reading the evidence", "Separate workload, build and sampling effects",
        para("All main results use west ingress into five connected regions: us-west-2, us-east-1, eu-west-1, ap-northeast-1 and ap-southeast-2. The topology has 15 clusters, 15 Stargates and 20 MockDynamo/Pylon backends.") +
        table(["Control", "Recorded configuration"], [
            ["Engine capacity", "25 slots per backend; 500 configured slots in total"],
            ["Statistics", "Mock engine stats stream disabled; Pylon fallback estimates"],
            ["Calibration", "Startup enabled; maximum concurrency 25; periodic canaries off"],
            ["Request limits", "10 s SLO / maximum wait; 30 s client timeout; output cap 256"],
            ["Original build A", "Application commit 1309d5d642dd"],
            ["Maximum-TPS build B", "Application commit 8a981aeadd31; Pylon, relays and Stargate upgraded"],
            ["Other controls in the build B pair", "MockDynamo, Spark, workload and resources stayed pinned"]]) +
        table(["Experiment", "What was held / varied", "Interpretation"], [
            ["Reduced suite / cold sweep", "One matched pair per workload or cap", "Fixed-duration counts exclude window-end cancellations; p99 is a histogram bucket lower bound"],
            ["Growing sessions", "768 sessions x 16 turns; 12,288 requests; two pairs per cap; order reversed", "Observed min/max ranges, not confidence intervals; cold reset each arm; final drain"],
            ["Continuous ramps", "768 fixed prompts; 6,661 input tokens; 5 x 180 s steps", "Cold reset once per arm; caches persist between steps; final drain; recorded exact timeline p99"],
            ["Maximum versus mean", "One mean-then-maximum pair on build B", "Selector comparison; no fresh WaW/PowerOf2 control on build B"]], "compact") +
        '<h2>Policies under test</h2>' + table(["Algorithm", "Relevant settings"], [
            ["PowerOf2", "PowerOfN, sample_count 2; TTFT comparator"],
            ["Ordinary WaW", "Queue-4 candidate; queue bounds omitted; utilization comparator; input scale 0.1. Session variants: 2 affine / 200 ms, then 1 affine / 300 ms"],
            ["Pulsar-WaW", "4,000/4,000 ms queue bounds; max_queued 4; n=2; 20 ms TTFT buckets; unlock factor 0.25; KV-free check off"],
            ["Pulsar weight", "Mean explicitly selected versus generation maximum as default. Maximum can still rise during traffic; it is not a fixed calibration constant"]], "compact") +
        para("Rate labels are caps, not guaranteed offered or admitted load. Reuse is not engine prefill throughput. Latency quantiles include retries but exclude terminal failures. Different workload and quantile definitions must not be pooled into one capacity estimate.", "note"))

    page("Fixed-prompt ramps / All algorithms", "Compare within each build group",
        para("Group A contains the original WaW/PowerOf2 pair and the later mean-based Pulsar follow-up, which reused those controls. Group B is the fresh mean/maximum pair. Both use the same ramp shape; group B uses newer application images.") +
        figure("02-ramp-scorecard", "Whole-arm values include the final drain. Shaded rows are build B (8a981aeadd31); unshaded rows are build A (1309d5d642dd). Cross-build comparisons are historical context, not a controlled ranking. Failures are HTTP 429 in A and HTTP 503 in B.", 177) +
        para("PowerOf2 has the strongest aggregate throughput, tails and failure count in the original-build ramp comparison. Maximum weighting improves Pulsar within build B, but no same-build PowerOf2 arm was run. A production winner is not established.", "finding"))

    reduced = rows("five_region_reduced")
    page("Five regions / Reduced workload suite", "Session gains do not apply to every workload",
        para("One matched pair per workload, using build A. The hot and short streams ran concurrently in the mixed arm. All reports in this table have zero terminal failures and zero client retries.") +
        figure("03-workload-changes", "Derived percent changes from published rounded values. Green indicates a favorable direction; red indicates an unfavorable direction. Higher throughput is favorable; lower latency is favorable.", 98) +
        table(["Workload", "Algorithm", "Success RPS", "Cache hits", "TTFT p99 s", "E2E p99 s"], [[r["dimensions"]["workload"].replace("Cold 96 RPS, 192 workers", "Cold 96 / 192 workers"), r["dimensions"]["algorithm"], fmt(r,"successful_rps",3), fmt(r,"cache_hit_percent",2)+"%", fmt(r,"ttft_p99_ms",3,1000), fmt(r,"e2e_p99_ms",3,1000)] for r in reduced], "compact") +
        para("Session affinity: WaW delivers 6.1% more successful throughput and 32.8% lower TTFT p99, with 89.19% cache hits versus 24.54%. Mixed-hot end-to-end p99 rises 73.7%, despite almost unchanged throughput.", "finding") +
        para("These cache values are request-level KV observations, not input-token reuse. Latency p99 is a histogram bucket lower bound. Fixed-duration reports exclude window-end in-flight cancellations.", "small"))

    cold = rows("five_region_cold_capacity")
    page("Five regions / Cold-capacity sweep", "WaW falls behind at the higher load caps",
        para("Each arm lasts 120 s and uses disjoint cold prompts; reported cache hits are zero. Each cap has one matched pair. Client concurrency rises across the sweep, and cache/estimator state is carried between arms.") +
        figure("04-cold-capacity", "Points are separate published arms; connecting segments are guides. p99 values are histogram bucket lower bounds. Retry rates are derived as retries / recorded requests x 1,000.", 144) +
        table(["RPS cap", "Workers", "WaW success RPS", "PowerOf2 success RPS", "WaW / P2 failures"], [[rate, one("five_region_cold_capacity",rate_cap_rps=rate,algorithm="WaW")["dimensions"]["workers"], fmt(one("five_region_cold_capacity",rate_cap_rps=rate,algorithm="WaW"),"successful_rps",3), fmt(one("five_region_cold_capacity",rate_cap_rps=rate,algorithm="PowerOf2"),"successful_rps",3), fmt(one("five_region_cold_capacity",rate_cap_rps=rate,algorithm="WaW"),"failures",0)+" / "+fmt(one("five_region_cold_capacity",rate_cap_rps=rate,algorithm="PowerOf2"),"failures",0)] for rate in [96,160,200,240,320]], "compact") +
        para("Throughput is close through the 200 RPS cap. At 240 and 320, WaW is 7.0% and 7.6% lower, with worse tail latency and more retries. An earlier unaccepted PowerOf2 attempt with generator DNS errors was excluded; the accepted 320 RPS pair used the corrected descriptor limit.", "finding"))

    page("Five regions / Growing sessions", "Higher low-load reuse; the high-load drop remains",
        para("Each column has its own matched PowerOf2 controls: two repeats per algorithm and cap, with reversed order. Both candidates use 768 sessions with 16 growing turns, cold reset and final drain. The two candidates ran on different dates.") +
        figure("05-growing-session-ranges", "Vertical spans show the published min/max across two repeats; they are not confidence intervals or averages. Equal printed endpoints appear as one tick. Throughput axes begin at 140 requests/s. Latency p99 is a histogram bucket lower bound.", 174) +
        para("At 160 RPS, one affine backend / 300 ms raises observed reuse to 88.0-89.0%, versus 68.5-70.3% for two / 200 ms. At 200-320, both candidates lose throughput to their matched PowerOf2 controls and retain only about 9-18% reuse.", "finding") +
        para("Both affine count and wait changed together; their individual effects are not isolated. Fewer evictions and higher low-load reuse did not resolve the high-load drop.", "small"))

    page("Build A / Continuous fixed-prompt ramps", "Cache reuse depends on the path through load",
        para("The 160 / 180 / 200 / 180 / 160 RPS sequence keeps sessions, caches and in-flight work across steps. WaW uses one affine backend and a 300 ms wait. Pulsar uses mean weighting and a different policy, including fixed 4,000 ms queue bounds.") +
        figure("06-original-ramp", "Each bar is a published step summary. Reuse uses the final 120 s; throughput uses the full 180 s completion window; p99 uses the full-step admission cohort. The small grey marks in the throughput panel are configured caps. Pulsar reused the earlier WaW/PowerOf2 controls.", 153) +
        para("Ordinary WaW reaches 96.75% settled reuse at opening 160, drops during upward 180, remains near 8% at 200 and returning 180, then recovers to 95.57% at 160. PowerOf2 stays near 5-6% reuse but has better aggregate throughput and latency tails.", "finding") +
        para("The first mean-based Pulsar arm is worse overall than the reused controls. Its observed mean-TPS weight movement is a diagnostic lead, not a per-key trace or proof of a sole cause. Five aggregate windows cannot recover the exact transition timing.", "small"))

    page("Build B / Maximum-TPS tradeoff", "The failure regression must stay visible",
        para("The same-build selector change improves successful throughput, input reuse and successful-request tails. It also increases terminal failures from 4 to 73 and retries from 8,183 to 13,389. Every terminal failure in this pair is HTTP 503.", "lead") +
        figure("07-maximum-failures-retries", "Exposure-normalized rates derived from published totals. Raw counts are in the summary table on page 1. The older campaigns' HTTP 429 outcomes must not be substituted for these HTTP 503s.", 85) +
        '<h2>What the pair supports</h2>' + bullets([
            "Maximum weighting sustains 88.61% input reuse in the settled upward 180 RPS window, versus 6.59% for mean.",
            "The reuse drop still occurs at 200 RPS. It persists when returning to 180 and recovers at 160. The maximum signal delays this observed transition; it does not eliminate it.",
            "p99 values cover successful requests only. Lower successful-request p99 together with more failures is a tradeoff, not a failure-aware SLO win.",
            "One mean-then-maximum pair does not quantify run-to-run variability, order effects or a stable production threshold."]) +
        '<h2>What it does not establish</h2>' + para("There is no fresh build-B PowerOf2 or ordinary WaW control. Historical PowerOf2 is numerically better in aggregate throughput, tails and failures, but those values do not isolate the selector change. The preserved summaries also do not establish the underlying cause of the HTTP 503 regression.") +
        para("Production recommendation remains pending real-engine QA. Keep the maximum-TPS result as a candidate improvement with an explicit reliability tradeoff.", "note"))

    hist = rows("historical_two_region_reduced")
    page("Appendix / Earlier two-region context", "The smaller topology showed similar tradeoffs",
        para("These results use eight backends across two regions. They are separate from the 20-backend study and must not be pooled into one capacity estimate. Each reduced comparison has one pair.") +
        figure("08-two-region-context", "WaW change versus its matched PowerOf2 control in the earlier two-region reduced suite. Percent changes here are derived from the rounded result rows.", 95) +
        table(["Workload", "Algorithm", "Success RPS", "Retries", "Cache hits", "TTFT p99 s", "E2E p99 s"], [[r["dimensions"]["workload"],r["dimensions"]["algorithm"],fmt(r,"successful_rps",3),fmt(r,"retries",0),fmt(r,"cache_hit_percent",2)+"%",fmt(r,"ttft_p99_ms",3,1000),fmt(r,"e2e_p99_ms",3,1000)] for r in hist], "compact") +
        para("The session pair favors WaW, while mixed-hot and cold-capacity results have latency or throughput costs. All reduced-suite table rows report zero terminal failures. A separate three-pair overload check recorded a median throughput gain of 20.9%, with a 13.0-23.3% observed range; it is a different experiment, not a replication of this table.") +
        para("The historical configuration screen covered 42 bundles. Its retained summaries motivate the queue-4 candidate but do not provide all per-configuration raw measurements for reconstruction. p99 values in this appendix are histogram bucket lower bounds.", "small"))

    page("Conclusions / Evidence record", "Keep PowerOf2 as the benchmark and test the tradeoff",
        '<h2>Next measurements, in order</h2>' + bullets([
            "Run a fresh same-build comparison of PowerOf2, ordinary WaW, Pulsar mean and Pulsar maximum. Use multiple matched blocks and reverse or randomize order.",
            "Diagnose the HTTP 503 regression with request/attempt failure reasons, routing deadlines and backend errors. Include failed requests in SLO attainment.",
            "Bracket the cache-reuse transition with finer load steps and longer plateaus around 180-200 RPS. Test cold-start and prewarmed runs separately; report achieved admissions.",
            "Vary affine count, wait and working-set size separately. Record per-backend cache occupancy/evictions, queue depth, mean/max TPS and bounded owner/rank movement.",
            "Repeat the decisive cases on real engines with true prefix caching and dynamic batching before a production recommendation."]) +
        '<h2>Limits that change the interpretation</h2>' + para("MockDynamo models an affinity-key/token-count LRU and fixed input/decode timing. It does not reproduce real prefix hashing or dynamic batching. Aggregate cache fit does not guarantee per-backend residency. Routing spill, duplication and eviction are plausible contributors; this study does not isolate their causal order.") +
        para("No confidence intervals can be reconstructed. The fixed-duration, growing-session and continuous-ramp experiments have different workload, censoring and quantile semantics. Telemetry gaps cannot establish continuous healthy connectivity. Final connection checks were recorded at test completion; they are not a current cluster-health check.") +
        '<h2>Sources and reproducibility</h2>' + para('<a href="https://github.com/NVIDIA/nvcf/pull/1519">NVIDIA/nvcf PR #1519</a>: deployment, benchmark methods and historical results. <a href="https://github.com/NVIDIA/nvcf/pull/1002">PR #1002</a>: maximum-TPS implementation and the same-build pair. The duplicated pair is counted once. Snapshots were captured on 2026-10-01; both PR bodies were last updated on 2026-09-30.') +
        para("The report bundle includes the captured PR JSON bodies, source-cell provenance, normalized JSON/CSV values, generation scripts, and every graph in PNG/SVG form. The data extraction cross-checks the preserved summaries; it does not revalidate deleted request logs or their original hashes.") +
        table(["Bundle file", "Purpose"], [["report.pdf / report.html", "Portable report and self-contained browser version"], ["results.json / results.csv", "Published values, ranges, definitions and source locations"], ["graphs/*.svg / *.png", "Standalone figures suitable for sharing"], ["sources/pr1519.json / pr1002.json", "Frozen source descriptions used for this report"], ["extract_results.py / build_report.py / render_pdf.py", "Reproducible extraction, figures and rendering"]], "compact") +
        para("Decision: retain PowerOf2 as the reference. Maximum-TPS Pulsar is promising for cache retention below the tested overload transition, with a reliability regression still to resolve. Production recommendation remains pending real-engine QA.", "finding"))

    assert len(PAGES) == 10
    doc = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Stargate routing performance | Final report</title><style>'+STYLE+'</style></head><body>'+''.join(PAGES)+'</body></html>'
    (ROOT/"report.html").write_text(doc)
    manifest = {"report_date":"2026-10-01", "pages":len(PAGES), "raw_artifacts_available":False,
        "evidence_basis":"Preserved PR summaries with published rounding", "graphs":sorted(p.name for p in CHARTS.iterdir()),
        "results_sha256":hashlib.sha256((ROOT/"results.json").read_bytes()).hexdigest(),
        "sources": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/"sources").glob('*.json')}}
    (ROOT/"report-manifest.json").write_text(json.dumps(manifest,indent=2)+'\n')
    print(f'Wrote {len(PAGES)} report pages and {len(list(CHARTS.glob("*.svg")))} figures')


if __name__ == "__main__":
    report()
